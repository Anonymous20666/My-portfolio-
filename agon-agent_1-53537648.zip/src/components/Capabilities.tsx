import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ChevronDown, Rocket, ShieldCheck, CalendarClock, PenTool, Hammer } from 'lucide-react';
import { capabilities, processSteps } from '../data';
import { requestStart } from '../lib/hooks';

export default function Capabilities() {
  const [open, setOpen] = useState(0);

  return (
    <>
      {/* ------------------------------------------------ Capabilities --- */}
      <section id="capabilities" className="scroll-mt-20 border-b border-line">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:gap-16 lg:px-8 lg:py-24">
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-24">
              <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">What we do</p>
              <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl">
                Five crafts.<br /><span className="font-serif italic font-normal text-gradient">One discipline.</span>
              </h2>
              <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-mute">
                Every engagement ends in the same place: a fast, honest, measurable product that happens to feel magical.
                Fixed scope, fixed bid, one senior team.
              </p>
              <button onClick={() => requestStart()} className="group mt-7 inline-flex items-center gap-2 font-display text-[12px] font-semibold uppercase tracking-[0.18em] text-accent-soft transition-colors hover:text-white">
                Get a fixed estimate in 3 days
                <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
              </button>
              <div className="mt-8 hidden items-center gap-3 rounded-2xl border border-line bg-card p-4 lg:flex">
                <ShieldCheck size={22} className="shrink-0 text-accent-2" strokeWidth={1.8} />
                <p className="text-[11.5px] leading-snug text-mute">
                  <span className="font-semibold text-ivory">Performance contract.</span> ≥90 mobile Lighthouse and ≤1.5s LCP at p75 — or we fix it free, forever.
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8">
            <div className="divide-y divide-line border-y border-line">
              {capabilities.map((cap, i) => {
                const isOpen = open === i;
                return (
                  <div key={cap.index}>
                    <button
                      onClick={() => setOpen(isOpen ? -1 : i)}
                      aria-expanded={isOpen}
                      className="group flex w-full items-center gap-4 px-2 py-5 text-left transition-colors sm:gap-6 sm:px-4 sm:py-6"
                    >
                      <span className={`font-serif text-base italic transition-colors ${isOpen ? 'text-accent-2' : 'text-mute'}`}>{cap.index}</span>
                      <span className="min-w-0 flex-1">
                        <span className={`block font-display text-lg font-semibold tracking-tight transition-colors sm:text-2xl ${isOpen ? 'text-white' : 'text-ivory group-hover:text-white'}`}>
                          {cap.title}
                        </span>
                        <span className="mt-1 block text-[11.5px] leading-snug text-mute">{cap.blurb}</span>
                      </span>
                      <span className="hidden shrink-0 text-right sm:block">
                        <span className="block text-[13px] font-semibold tabular-nums text-ivory">{cap.from}</span>
                        <span className="block text-[9px] uppercase tracking-[0.16em] text-mute">{cap.timeline}</span>
                      </span>
                      <ChevronDown size={18} className={`shrink-0 text-mute transition-transform duration-300 ${isOpen ? 'rotate-180 text-accent-2' : ''}`} />
                    </button>
                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          key="panel"
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.34, ease: [0.32, 0.72, 0.2, 1] }}
                          className="overflow-hidden"
                        >
                          <div className="grid gap-4 pb-6 pl-10 pr-2 sm:grid-cols-[1fr_auto] sm:pl-16 sm:pr-6">
                            <ul className="grid gap-2 sm:grid-cols-2">
                              {cap.detail.map((d) => (
                                <li key={d} className="flex items-start gap-2 text-[12px] leading-snug text-ivory/80">
                                  <span className="mt-[5px] h-1 w-1 shrink-0 rounded-full bg-accent-2" />
                                  {d}
                                </li>
                              ))}
                            </ul>
                            <div className="flex flex-row items-center gap-4 rounded-2xl border border-line bg-card px-4 py-3 sm:w-40 sm:flex-col sm:items-end sm:justify-center sm:text-right">
                              <div>
                                <p className="text-[9px] uppercase tracking-[0.18em] text-mute">From</p>
                                <p className="font-display text-lg font-semibold text-ivory">{cap.from}</p>
                              </div>
                              <div>
                                <p className="text-[9px] uppercase tracking-[0.18em] text-mute">Timeline</p>
                                <p className="font-display text-[13px] font-semibold text-accent-soft">{cap.timeline}</p>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex items-center justify-between gap-4 px-2 sm:px-4">
              <p className="text-[11px] text-mute">Every price is an anchor — your bid is fixed in writing after a 30-minute call.</p>
              <span className="hidden items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-mute sm:inline-flex"><Rocket size={12} className="text-accent-2" /> 14 slots / yr</span>
            </div>
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------- Process --- */}
      <section id="process" className="scroll-mt-20 border-b border-line bg-panel/40">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">How it works</p>
              <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl">
                Twelve weeks.<br /><span className="font-serif italic font-normal text-gradient">Zero mystery.</span>
              </h2>
            </div>
            <p className="max-w-xs text-[12.5px] leading-relaxed text-mute">
              One integrated team — strategy, design, CGI and engineering — on a fixed bid with weekly playable builds.
            </p>
          </div>

          <ol className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {processSteps.map((step) => (
              <li key={step.step} className="group relative flex flex-col gap-4 bg-panel p-6 transition-colors duration-300 hover:bg-panel-2">
                <div className="flex items-center justify-between">
                  <span className="font-serif text-4xl italic text-line-2 transition-colors duration-300 group-hover:text-accent">{step.step}</span>
                  {[PenTool, CalendarClock, Hammer, Rocket].map((Icon, idx) =>
                    ['01', '02', '03', '04'][idx] === step.step ? <Icon key={idx} size={18} className="text-mute" strokeWidth={1.6} /> : null
                  )}
                </div>
                <div>
                  <h3 className="font-display text-lg font-semibold tracking-tight text-ivory">{step.title}</h3>
                  <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-accent-soft">{step.weeks}</p>
                </div>
                <ul className="space-y-2">
                  {step.points.map((point) => (
                    <li key={point} className="flex items-start gap-2 text-[11.5px] leading-snug text-mute">
                      <span className="mt-[5px] h-1 w-1 shrink-0 rounded-full bg-accent" />
                      {point}
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ol>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-[11px] font-medium uppercase tracking-[0.16em] text-mute">
            <span className="flex items-center gap-2"><span className="h-1 w-1 rounded-full bg-accent-2" /> Fixed bid, always</span>
            <span className="flex items-center gap-2"><span className="h-1 w-1 rounded-full bg-accent-2" /> Playable build every Friday</span>
            <span className="flex items-center gap-2"><span className="h-1 w-1 rounded-full bg-accent-2" /> You own the repo from day one</span>
          </div>
        </div>
      </section>
    </>
  );
}
