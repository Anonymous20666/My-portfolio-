import { useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, X } from 'lucide-react';

/* ------------------------------------------------------------------ Modal */

export function Modal({
  open,
  onClose,
  children,
  maxWidth = 'max-w-2xl',
  label,
}: {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  maxWidth?: string;
  label: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="backdrop"
          className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="dialog"
          aria-modal="true"
          aria-label={label}
        >
          <div className="absolute inset-0 bg-black/78 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            className={`relative w-full ${maxWidth} max-h-[94svh] sm:max-h-[88svh] overflow-hidden rounded-t-3xl sm:rounded-3xl border border-line-2 bg-panel shadow-[0_40px_120px_-20px_rgba(0,0,0,0.8)] flex flex-col`}
            initial={{ y: 72, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 48, opacity: 0, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 320, damping: 34 }}
          >
            <button
              onClick={onClose}
              aria-label="Close dialog"
              className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full border border-line-2 bg-black/30 text-mute transition-colors hover:text-white hover:border-accent"
            >
              <X size={17} strokeWidth={2} />
            </button>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ------------------------------------------------------------ ToastHost */

interface Toast {
  id: number;
  message: string;
}

export function ToastHost() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    let id = 0;
    const handler = (e: Event) => {
      const message = (e as CustomEvent<string>).detail;
      const toast = { id: ++id, message };
      setToasts((t) => [...t.slice(-2), toast]);
      window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== toast.id)), 4200);
    };
    window.addEventListener('vivid:toast', handler);
    return () => window.removeEventListener('vivid:toast', handler);
  }, []);

  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[110] flex w-full max-w-md -translate-x-1/2 flex-col items-center gap-2 px-4">
      <AnimatePresence>
        {toasts.map((toast) => (
          <motion.button
            key={toast.id}
            layout
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.97 }}
            onClick={() => dismiss(toast.id)}
            className="pointer-events-auto flex items-center gap-2.5 rounded-2xl border border-line-2 bg-panel-2/95 px-4 py-3 text-left text-[13px] text-ivory shadow-[0_18px_50px_-12px_rgba(0,0,0,0.7)] backdrop-blur-md"
          >
            <CheckCircle2 size={16} className="shrink-0 text-accent-2" strokeWidth={2.2} />
            <span>{toast.message}</span>
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  );
}
