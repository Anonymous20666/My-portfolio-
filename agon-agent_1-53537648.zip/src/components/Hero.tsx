import { ArrowDown, Play } from 'lucide-react';
import { HeroScene } from './scenes';
import { clients, stats } from '../data';
import { useCountUp, useInView } from '../lib/hooks';

function Stat({ value, suffix, label, active }: { value: number; suffix: string; label: string; active: boolean }) {
  const v = useCountUp(value, active, 1800);
  return (
    <div className="px-4 py-5 sm:px-6 md:py-7">
      <p className="font-display text-3xl font-semibold tracking-tight text-ivory tabular-nums sm:text-4xl">
        {v}
        {suffix && <span className="text-accent-2">{suffix}</span>}
      </p>
      <p className="mt-1.5 text-[10.5px] font-medium uppercase leading-snug tracking-[0.12em] text-mute">{label}</p>
    </div>
  );
}

export default function Hero({ onWatchReel }: { onWatchReel: () => void }) {
  const { ref: statsRef, inView: statsInView } = useInView<HTMLDivElement>(0.25);

  return (
    <section id="top" className="relative overflow-hidden">
      {/* ambient glows */}
      <div aria-hidden="true" className="pointer-events-none absolute -left-40 top-[-120px] h-[520px] w-[520px] rounded-full bg-accent/20 blur-[140px]" />
      <div aria-hidden="true" className="pointer-events-none absolute right-[-180px] top-[220px] h-[480px] w-[480px] rounded-full bg-accent-2/10 blur-[150px]" />

      <div className="mx-auto max-w-7xl px-4 pt-[68px] sm:px-6 lg:px-8">
        <div className="grid items-center gap-8 pb-10 pt-8 sm:pt-12 lg:grid-cols-12 lg:gap-10 lg:pb-16 lg:pt-16">
          {/* Copy */}
          <div className="relative z-10 lg:col-span-6">
            <div className="inline-flex items-center gap-2.5 rounded-full border border-line-2 bg-white/[0.03] py-1.5 pl-2 pr-4 backdrop-blur-sm">
              <span className="alive-dot" />
              <span className="text-[10.5px] font-medium uppercase tracking-[0.18em] text-ivory/90">Booking projects — Q1 2027</span>
            </div>

            <h1 className="mt-6 font-display font-semibold leading-[0.98] tracking-[-0.035em] text-ivory">
              <span className="block text-[44px] sm:text-6xl xl:text-[76px]">Professional 3D</span>
              <span className="block text-[44px] sm:text-6xl xl:text-[76px]">experiences that</span>
              <span className="font-serif block text-[48px] font-normal italic text-gradient sm:text-6xl xl:text-[80px]">feel truly alive.</span>
            </h1>

            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-mute sm:text-base">
              Vivid3D is a real-time 3D and WebGL studio crafting immersive websites, product configurators and
              brand worlds for ambitious companies — engineered for speed, built to be remembered.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#work" className="btn btn-primary">
                Explore our work
                <ArrowDown size={15} strokeWidth={2.4} />
              </a>
              <button onClick={onWatchReel} className="btn btn-ghost">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-accent">
                  <Play size={10} fill="#fff" strokeWidth={0} className="ml-0.5" />
                </span>
                Watch the reel
                <span className="text-mute">0:16</span>
              </button>
            </div>

            <div className="mt-9 flex items-center gap-5">
              <div className="flex -space-x-2.5">
                {['women/68', 'men/41', 'women/12', 'men/84'].map((id) => (
                  <img
                    key={id}
                    src={`https://randomuser.me/api/portraits/${id}.jpg`}
                    alt="Client portrait"
                    loading="lazy"
                    width={38}
                    height={38}
                    className="h-9 w-9 rounded-full border-2 border-ink object-cover"
                  />
                ))}
              </div>
              <p className="max-w-[210px] text-[11.5px] leading-snug text-mute">
                Trusted by brand &amp; product teams at{' '}
                <span className="font-semibold text-ivory">Aether, Nexus, Meridia</span> and 90+ others
              </p>
            </div>
          </div>

          {/* 3D stage */}
          <div className="relative lg:col-span-6">
            <div className="relative h-[340px] overflow-hidden rounded-3xl border border-line-2 bg-[radial-gradient(120%_120%_at_50%_0%,#171430_0%,#0d0c17_55%,#08070e_100%)] sm:h-[440px] lg:h-[560px]">
              <HeroScene className="absolute inset-0 h-full w-full cursor-grab active:cursor-grabbing" />
              {/* corner ticks */}
              <span className="tick tick-tl" /><span className="tick tick-tr" /><span className="tick tick-bl" /><span className="tick tick-br" />
              {/* HUD chrome */}
              <div className="pointer-events-none absolute left-4 top-4 flex items-center gap-2 rounded-full border border-line-2 bg-black/45 py-1.5 pl-2 pr-3 backdrop-blur-md">
                <span className="h-1.5 w-1.5 rounded-full bg-accent-2 shadow-[0_0_8px_2px_rgba(63,224,197,0.7)]" />
                <span className="font-display text-[9.5px] font-semibold uppercase tracking-[0.22em] text-ivory/90">Live · WebGL</span>
              </div>
              <div className="pointer-events-none absolute right-4 top-4 rounded-full border border-line-2 bg-black/45 px-3 py-1.5 backdrop-blur-md">
                <span className="font-display text-[9.5px] font-semibold uppercase tracking-[0.22em] text-ivory/80">60 FPS · 0 textures</span>
              </div>
              <div className="pointer-events-none absolute bottom-4 left-4">
                <p className="font-display text-[9.5px] font-semibold uppercase tracking-[0.24em] text-accent-soft">Orbital Core — v7</p>
                <p className="mt-1 text-[11px] text-mute">Drag your cursor across the stage. It’s listening.</p>
              </div>
              <div className="pointer-events-none absolute bottom-4 right-4 text-right">
                <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-mute">52.52° N · 13.40° E</p>
                <p className="font-mono text-[9.5px] uppercase tracking-[0.18em] text-mute">Berlin / Studio</p>
              </div>
            </div>
          </div>
        </div>

        {/* client marquee */}
        <div className="marquee-paused relative border-y border-line py-4" aria-hidden="true">
          <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-14 bg-gradient-to-r from-ink to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-14 bg-gradient-to-l from-ink to-transparent" />
          <div className="overflow-hidden">
            <div className="marquee-track">
              {[...clients, ...clients].map((client, i) => (
                <span key={i} className="flex items-center gap-8 pr-8">
                  <span className="whitespace-nowrap font-display text-sm font-medium uppercase tracking-[0.22em] text-mute transition-colors hover:text-ivory">{client}</span>
                  <span className="text-[10px] text-accent">◆</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* stats bar */}
        <div ref={statsRef} className="grid grid-cols-2 divide-x divide-line border-b border-line sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <Stat key={s.label} value={s.value} suffix={s.suffix} label={s.label} active={statsInView} />
          ))}
        </div>
      </div>
    </section>
  );
}
