import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import type { ProjectVariant } from '../data';

/* ------------------------------------------------------------------ helpers */

const reduceMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function disposeObject(root: THREE.Object3D) {
  root.traverse((obj) => {
    const mesh = obj as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose();
    const material = (obj as unknown as { material?: THREE.Material | THREE.Material[] }).material;
    if (Array.isArray(material)) material.forEach((m) => m.dispose());
    else if (material) material.dispose();
  });
}

interface MountResult {
  tick: (t: number) => void;
  camera: THREE.PerspectiveCamera;
  scene: THREE.Scene;
}

/**
 * Shared mount: sets up renderer, sized to canvas.parentElement, gates the
 * render loop on visibility, handles resize and full disposal on unmount.
 */
function mountScene(
  canvas: HTMLCanvasElement,
  build: (scene: THREE.Scene, camera: THREE.PerspectiveCamera) => MountResult
) {
  const parent = canvas.parentElement as HTMLElement;
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true,
    powerPreference: 'high-performance',
    stencil: false,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setClearColor(0x000000, 0);

  const scene = new THREE.Scene();
  // Image-based lighting so metals and clearcoat actually read — but dimmed to keep the night mood
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTexture = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTexture;
  scene.environmentIntensity = 0.5;
  const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 120);
  camera.position.set(0, 0.4, 8.4);

  const { tick } = build(scene, camera);

  const resize = () => {
    const w = Math.max(1, parent.clientWidth);
    const h = Math.max(1, parent.clientHeight);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    if (reduceMotion()) renderer.render(scene, camera);
  };
  const ro = new ResizeObserver(resize);
  ro.observe(parent);
  resize();

  const staticFrame = reduceMotion();
  const clock = new THREE.Clock();
  let raf = 0;
  let onScreen = false;

  const loop = () => {
    raf = requestAnimationFrame(loop);
    if (!onScreen) {
      cancelAnimationFrame(raf);
      raf = 0;
      return;
    }
    tick(clock.getElapsedTime());
    renderer.render(scene, camera);
  };

  const io = new IntersectionObserver(
    (entries) => {
      onScreen = entries[0]?.isIntersecting ?? false;
      if (staticFrame) {
        renderer.render(scene, camera);
        return;
      }
      if (onScreen && !raf) loop();
    },
    { rootMargin: '140px' }
  );
  io.observe(canvas);
  if (!staticFrame) loop();

  return () => {
    cancelAnimationFrame(raf);
    ro.disconnect();
    io.disconnect();
    scene.environment = null;
    envTexture.dispose();
    pmrem.dispose();
    disposeObject(scene);
    renderer.dispose();
  };
}

/** Pointer parallax relative to canvas centre, smoothed by the caller. */
function bindParallax(canvas: HTMLCanvasElement) {
  const state = { px: 0, py: 0, tx: 0, ty: 0 };
  const onMove = (e: PointerEvent) => {
    const r = canvas.getBoundingClientRect();
    state.tx = ((e.clientX - r.left) / Math.max(1, r.width)) * 2 - 1;
    state.ty = ((e.clientY - r.top) / Math.max(1, r.height)) * 2 - 1;
  };
  const onLeave = () => {
    state.tx = 0;
    state.ty = 0;
  };
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerleave', onLeave);
  return {
    state,
    lerp() {
      state.px += (state.tx - state.px) * 0.055;
      state.py += (state.ty - state.py) * 0.055;
      return state;
    },
    dispose() {
      canvas.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('pointerleave', onLeave);
    },
  };
}

function baseLights(scene: THREE.Scene, keyColor = 0xffffff, rimColor = 0x7c6cff) {
  scene.add(new THREE.HemisphereLight(0xcfd0ff, 0x0b0a14, 1.15));
  const key = new THREE.DirectionalLight(keyColor, 2.4);
  key.position.set(4.5, 6, 6.5);
  scene.add(key);
  const rim = new THREE.DirectionalLight(rimColor, 2.1);
  rim.position.set(-6, -2.5, -4);
  scene.add(rim);
  const fill = new THREE.DirectionalLight(0x3fe0c5, 0.55);
  fill.position.set(-3, 4, 2);
  scene.add(fill);
}

function makeParticles(count: number, rMin: number, rMax: number, size = 0.05, color = 0xbdb8ee) {
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const r = rMin + Math.random() * (rMax - rMin);
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.cos(phi);
    positions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const mat = new THREE.PointsMaterial({ size, color, transparent: true, opacity: 0.8, depthWrite: false });
  return new THREE.Points(geo, mat);
}

/* ------------------------------------------------------------- HERO SCENE */

export function HeroScene({ className = '' }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parallax = bindParallax(canvas);

    const cleanup = mountScene(canvas, (scene, camera) => {
      camera.position.set(0, 0.35, 8.6);
      camera.lookAt(0, 0, 0);
      baseLights(scene);

      const group = new THREE.Group();
      scene.add(group);

      // Orbital core — metallic icosahedron with plasma skin
      const coreGeo = new THREE.IcosahedronGeometry(1.72, 24);
      const coreMat = new THREE.MeshStandardMaterial({
        color: 0x17161f,
        metalness: 0.92,
        roughness: 0.16,
        emissive: 0x2c2358,
        emissiveIntensity: 0.55,
        flatShading: false,
      });
      const core = new THREE.Mesh(coreGeo, coreMat);
      group.add(core);

      // Lat/long wire shell
      const shellGeo = new THREE.IcosahedronGeometry(2.02, 1);
      const shellEdges = new THREE.EdgesGeometry(shellGeo, 8);
      const shell = new THREE.LineSegments(
        shellEdges,
        new THREE.LineBasicMaterial({ color: 0x8f7fff, transparent: true, opacity: 0.85 })
      );
      group.add(shell);

      // Inner plasma sphere
      const plasma = new THREE.Mesh(
        new THREE.SphereGeometry(0.62, 32, 32),
        new THREE.MeshBasicMaterial({ color: 0xb9a8ff, transparent: true, opacity: 0.95 })
      );
      group.add(plasma);
      const glow = new THREE.Mesh(
        new THREE.SphereGeometry(0.95, 32, 32),
        new THREE.MeshBasicMaterial({ color: 0x7c6cff, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false })
      );
      group.add(glow);

      // Three gyroscopic rings
      const ringDefs = [
        { radius: 2.62, tube: 0.028, color: 0x7c6cff, opacity: 0.9, tilt: [Math.PI / 2.6, 0.3] },
        { radius: 3.08, tube: 0.02, color: 0x3fe0c5, opacity: 0.75, tilt: [Math.PI / 1.9, -0.55] },
        { radius: 3.52, tube: 0.014, color: 0xedebf6, opacity: 0.35, tilt: [Math.PI / 3.3, 1.1] },
      ];
      const rings = ringDefs.map((d) => {
        const ring = new THREE.Mesh(
          new THREE.TorusGeometry(d.radius, d.tube, 12, 128),
          new THREE.MeshBasicMaterial({ color: d.color, transparent: true, opacity: d.opacity })
        );
        ring.rotation.set(d.tilt[0], d.tilt[1], 0);
        group.add(ring);
        return ring;
      });

      // Orbiting satellites
      const satellites = [2.62, 3.08, 3.52].map((r, i) => {
        const sat = new THREE.Mesh(
          new THREE.SphereGeometry(0.075 + i * 0.02, 16, 16),
          new THREE.MeshBasicMaterial({ color: [0xa89bff, 0x3fe0c5, 0xedebf6][i] })
        );
        group.add(sat);
        return { mesh: sat, radius: r, speed: 0.32 - i * 0.09, phase: i * 2.1, ring: rings[i] };
      });

      // Particle field
      const particles = makeParticles(320, 4.6, 8.2, 0.045, 0xbdb8ee);
      scene.add(particles);

      // Backdrop halo
      const halo = new THREE.Mesh(
        new THREE.RingGeometry(2.2, 4.35, 64),
        new THREE.MeshBasicMaterial({ color: 0x241f45, transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false })
      );
      halo.position.z = -2.6;
      scene.add(halo);

      return {
        camera,
        scene,
        tick: (t: number) => {
          const { px, py } = parallax.lerp();
          core.rotation.y = t * 0.24 + px * 0.5;
          core.rotation.x = t * 0.11 + py * 0.4;
          const pulse = 1 + Math.sin(t * 1.5) * 0.022;
          core.scale.setScalar(pulse);
          shell.rotation.copy(core.rotation);
          shell.scale.setScalar(pulse + Math.sin(t * 1.5 + 0.6) * 0.018);
          plasma.scale.setScalar(1 + Math.sin(t * 2.1) * 0.14);
          (glow.material as THREE.Material).opacity = 0.22 + (Math.sin(t * 2.1) * 0.5 + 0.5) * 0.18;

          rings[0].rotation.z = t * 0.32;
          rings[1].rotation.z = -t * 0.21;
          rings[2].rotation.z = t * 0.14;
          rings[0].rotation.x = Math.PI / 2.6 + Math.sin(t * 0.4) * 0.14;
          rings[1].rotation.x = Math.PI / 1.9 + Math.cos(t * 0.3) * 0.16;

          particles.rotation.y = t * 0.028;
          particles.rotation.x = Math.sin(t * 0.12) * 0.06;

          // satellites ride their rings (ring local space → world)
          satellites.forEach(({ mesh, radius, speed, phase, ring }) => {
            const a = t * speed + phase;
            const local = new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, 0);
            ring.localToWorld(local);
            group.worldToLocal(local);
            mesh.position.copy(local);
          });

          group.rotation.y = px * 0.22;
          group.rotation.x = py * -0.14;
          camera.position.x = px * 0.5;
          camera.position.y = 0.35 - py * 0.35;
          camera.lookAt(0, 0, 0);
        },
      };
    });

    return () => {
      parallax.dispose();
      cleanup();
    };
  }, []);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />;
}

/* ------------------------------------------------------- PROJECT CARD 3D */

export function ProjectScene({ variant, accent, className = '' }: { variant: ProjectVariant; accent: string; className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hoverRef = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parallax = bindParallax(canvas);
    const accentColor = new THREE.Color(accent);
    const onEnter = () => (hoverRef.current = true);
    const onLeave = () => (hoverRef.current = false);
    canvas.addEventListener('pointerenter', onEnter);
    canvas.addEventListener('pointerleave', onLeave);

    const cleanup = mountScene(canvas, (scene, camera) => {
      camera.position.set(0, 0.15, 5.1);
      camera.lookAt(0, 0, 0);
      baseLights(scene, 0xffffff, accentColor.getHex());

      const group = new THREE.Group();
      scene.add(group);
      const extraTick: ((t: number, hover: number) => void)[] = [];

      switch (variant) {
        case 'knot': {
          const knot = new THREE.Mesh(
            new THREE.TorusKnotGeometry(1.02, 0.32, 200, 36, 2, 3),
            new THREE.MeshStandardMaterial({ color: 0x2e2947, metalness: 0.65, roughness: 0.24, emissive: accentColor, emissiveIntensity: 0.38, flatShading: true })
          );
          group.add(knot);
          extraTick.push((t, h) => {
            knot.rotation.x = t * (0.35 + h * 0.4);
            knot.rotation.y = t * (0.28 + h * 0.45);
          });
          break;
        }
        case 'orbit': {
          const sun = new THREE.Mesh(
            new THREE.IcosahedronGeometry(0.62, 1),
            new THREE.MeshStandardMaterial({ color: 0x111722, metalness: 0.9, roughness: 0.25, emissive: accentColor, emissiveIntensity: 0.9, flatShading: true })
          );
          group.add(sun);
          const orbiters: { mesh: THREE.Mesh; r: number; speed: number; phase: number }[] = [];
          [1.15, 1.75, 2.35].forEach((r, i) => {
            const orbit = new THREE.Mesh(
              new THREE.TorusGeometry(r, 0.012, 8, 72),
              new THREE.MeshBasicMaterial({ color: 0x3fe0c5, transparent: true, opacity: 0.32 })
            );
            orbit.rotation.x = Math.PI / 2.15 + i * 0.32;
            orbit.rotation.y = i * 0.5;
            group.add(orbit);
            const sat = new THREE.Mesh(
              new THREE.SphereGeometry(0.13 - i * 0.03, 18, 18),
              new THREE.MeshStandardMaterial({ color: 0x1a2430, metalness: 0.8, roughness: 0.3, emissive: 0x3fe0c5, emissiveIntensity: 1.1 - i * 0.3 })
            );
            group.add(sat);
            orbiters.push({ mesh: sat, r, speed: 0.55 - i * 0.17, phase: i * 2.2 });
            void orbit;
          });
          extraTick.push((t, h) => {
            sun.rotation.y = t * 0.4;
            orbiters.forEach((o, i) => {
              const a = t * (o.speed + h * 0.35) + o.phase;
              o.mesh.position.set(Math.cos(a) * o.r, Math.sin(a) * o.r * 0.42, Math.sin(a + 1.2) * 0.55);
            });
          });
          break;
        }
        case 'grid': {
          // Instanced data-city skyline, breathing
          const COLS = 13, ROWS = 13;
          const box = new THREE.BoxGeometry(0.16, 1, 0.16);
          box.translate(0, 0.5, 0);
          const mat = new THREE.MeshStandardMaterial({ color: 0x181a26, metalness: 0.55, roughness: 0.4, emissive: accentColor, emissiveIntensity: 0.35 });
          const inst = new THREE.InstancedMesh(box, mat, COLS * ROWS);
          group.add(inst);
          const dummy = new THREE.Object3D();
          const setHeights = (t: number) => {
            let i = 0;
            for (let x = 0; x < COLS; x++) {
              for (let z = 0; z < ROWS; z++) {
                const dx = x - COLS / 2, dz = z - ROWS / 2;
                const dist = Math.sqrt(dx * dx + dz * dz);
                const hgt = 0.18 + Math.pow(Math.max(0, Math.sin(dist * 1.15 - t * 1.15)), 2) * 1.7 + Math.sin(x * 1.7 + z * 2.3 + t * 0.8) * 0.08;
                dummy.position.set(dx * 0.3, -0.85, dz * 0.3);
                dummy.scale.set(1, hgt, 1);
                dummy.updateMatrix();
                inst.setMatrixAt(i++, dummy.matrix);
              }
            }
            inst.instanceMatrix.needsUpdate = true;
          };
          setHeights(0);
          group.rotation.x = -0.52;
          group.rotation.y = 0.45;
          extraTick.push((t, h) => {
            setHeights(t * (1 + h * 0.9));
            group.rotation.y = 0.45 + Math.sin(t * 0.18) * 0.22;
          });
          break;
        }
        case 'gem': {
          const gem = new THREE.Mesh(
            new THREE.OctahedronGeometry(1.42, 0),
            new THREE.MeshStandardMaterial({ color: 0x0e2b26, metalness: 0.95, roughness: 0.08, emissive: accentColor, emissiveIntensity: 0.42, flatShading: true })
          );
          group.add(gem);
          const haloGem = new THREE.Mesh(
            new THREE.OctahedronGeometry(1.72, 0),
            new THREE.MeshBasicMaterial({ color: 0x3fe0c5, wireframe: true, transparent: true, opacity: 0.35 })
          );
          group.add(haloGem);
          const sparkles = makeParticles(90, 1.9, 3.1, 0.05, 0x9ff5dd);
          group.add(sparkles);
          extraTick.push((t, h) => {
            gem.rotation.y = t * (0.45 + h * 0.5);
            gem.rotation.x = Math.sin(t * 0.4) * 0.35;
            gem.position.y = Math.sin(t * 1.35) * 0.12;
            haloGem.rotation.y = -t * 0.2;
            haloGem.rotation.x = gem.rotation.x * 0.6;
            sparkles.rotation.y = t * 0.12;
          });
          break;
        }
        case 'torus': {
          // Gold bezel homage — the Lumen case
          const bezel = new THREE.Mesh(
            new THREE.TorusGeometry(1.08, 0.34, 28, 96),
            new THREE.MeshStandardMaterial({ color: 0x8a6a25, metalness: 1, roughness: 0.18, emissive: accentColor, emissiveIntensity: 0.18 })
          );
          group.add(bezel);
          const dial = new THREE.Mesh(
            new THREE.CircleGeometry(0.78, 48),
            new THREE.MeshStandardMaterial({ color: 0x120f08, metalness: 0.35, roughness: 0.5, emissive: 0x2a2110, emissiveIntensity: 0.7 })
          );
          dial.position.z = 0.02;
          group.add(dial);
          const hand = new THREE.Mesh(
            new THREE.BoxGeometry(0.045, 0.62, 0.02),
            new THREE.MeshBasicMaterial({ color: 0xe7c268 })
          );
          hand.geometry.translate(0, 0.26, 0);
          hand.position.z = 0.05;
          group.add(hand);
          extraTick.push((t, h) => {
            group.rotation.y = Math.sin(t * 0.5) * (0.5 + h * 0.35);
            group.rotation.x = Math.cos(t * 0.35) * 0.18;
            hand.rotation.z = -t * (0.9 + h * 1.6);
          });
          break;
        }
        case 'wave': {
          const geo = new THREE.PlaneGeometry(7.4, 4.4, 52, 30);
          const mat = new THREE.MeshStandardMaterial({ color: 0x141327, metalness: 0.2, roughness: 0.62, emissive: 0x352a75, emissiveIntensity: 0.55, flatShading: true, side: THREE.DoubleSide });
          const plane = new THREE.Mesh(geo, mat);
          plane.rotation.x = -0.62;
          group.add(plane);
          const pos = geo.attributes.position as THREE.BufferAttribute;
          const base = (pos.array as Float32Array).slice();
          const amp = (x: number, y: number, t: number) =>
            Math.sin(x * 1.25 + t * 1.35) * 0.22 + Math.cos(y * 1.9 + t * 1.05) * 0.16 + Math.sin((x + y) * 0.8 + t * 0.7) * 0.12;
          extraTick.push((t, h) => {
            const boost = 1 + h * 0.8;
            for (let i = 0; i < pos.count; i++) {
              const x = base[i * 3], y = base[i * 3 + 1];
              pos.setZ(i, amp(x, y, t * boost));
            }
            pos.needsUpdate = true;
            geo.computeVertexNormals();
          });
          break;
        }
      }

      const particles = makeParticles(70, 2.6, 4.6, 0.032, 0x8f8bc9);
      scene.add(particles);

      return {
        camera,
        scene,
        tick: (t: number) => {
          const { px, py } = parallax.lerp();
          const hover = hoverRef.current ? 1 : 0;
          group.rotation.x += (py * 0.18 - group.rotation.x) * 0.05;
          extraTick.forEach((fn) => fn(t, hover));
          particles.rotation.y = t * 0.05;
          camera.position.x += (px * 0.65 - camera.position.x) * 0.06;
          camera.position.y += (0.15 - py * 0.45 - camera.position.y) * 0.06;
          camera.lookAt(0, 0, 0);
        },
      };
    });

    return () => {
      canvas.removeEventListener('pointerenter', onEnter);
      canvas.removeEventListener('pointerleave', onLeave);
      parallax.dispose();
      cleanup();
    };
  }, [variant, accent]);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />;
}

/* ----------------------------------------------------- CONFIGURATOR WATCH */

export type CaseFinish = 'steel' | 'black' | 'rose';
export type DialColor = 'midnight' | 'ivory' | 'green' | 'slate' | 'champagne';
export type StrapColor = 'black' | 'tan' | 'forest';

const CASE_COLORS: Record<CaseFinish, number> = {
  steel: 0xd9dae2,
  black: 0x2a2a33,
  rose: 0xe3a084,
};
const DIAL_COLORS: Record<DialColor, { face: number; emissive: number }> = {
  midnight: { face: 0x111a33, emissive: 0x141f3f },
  ivory: { face: 0xe9e4d4, emissive: 0x4a463a },
  green: { face: 0x0f2e23, emissive: 0x14392b },
  slate: { face: 0x27272f, emissive: 0x2e2e3a },
  champagne: { face: 0xcbb27a, emissive: 0x59481f },
};
const STRAP_COLORS: Record<StrapColor, number> = {
  black: 0x171512,
  tan: 0x8a5a33,
  forest: 0x1d3a2a,
};

export function WatchScene({
  caseFinish,
  dial,
  strap,
  className = '',
}: {
  caseFinish: CaseFinish;
  dial: DialColor;
  strap: StrapColor;
  className?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const materialsRef = useRef<{
    caseMat: THREE.MeshStandardMaterial;
    bezelMat: THREE.MeshStandardMaterial;
    dialMat: THREE.MeshStandardMaterial;
    strapMat: THREE.MeshStandardMaterial;
  } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parallax = bindParallax(canvas);

    const cleanup = mountScene(canvas, (scene, camera) => {
      camera.position.set(0, 0.15, 6.4);
      camera.lookAt(0, 0, 0);
      baseLights(scene, 0xfff4e0, 0x7c6cff);

      const group = new THREE.Group();
      scene.add(group);

      const caseMat = new THREE.MeshStandardMaterial({ color: CASE_COLORS.steel, metalness: 1, roughness: 0.22 });
      const bezelMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(CASE_COLORS.steel).multiplyScalar(0.92), metalness: 1, roughness: 0.3 });
      const dialMat = new THREE.MeshStandardMaterial({ color: DIAL_COLORS.midnight.face, metalness: 0.15, roughness: 0.42, emissive: DIAL_COLORS.midnight.emissive, emissiveIntensity: 0.75 });
      const strapMat = new THREE.MeshStandardMaterial({ color: STRAP_COLORS.black, metalness: 0.05, roughness: 0.85 });
      materialsRef.current = { caseMat, bezelMat, dialMat, strapMat };

      // Strap (top & bottom), slightly tapered boxes
      const strapGeo = new THREE.BoxGeometry(1.35, 3.1, 0.34);
      const strapTop = new THREE.Mesh(strapGeo, strapMat);
      strapTop.position.y = 2.28;
      strapTop.rotation.x = 0.1;
      group.add(strapTop);
      const strapBottom = new THREE.Mesh(strapGeo.clone(), strapMat);
      strapBottom.position.y = -2.28;
      strapBottom.rotation.x = -0.1;
      group.add(strapBottom);
      // Strap keepers
      const keeperGeo = new THREE.BoxGeometry(1.42, 0.18, 0.4);
      [1.35, -1.35].forEach((y) => {
        const keeper = new THREE.Mesh(keeperGeo, bezelMat);
        keeper.position.y = y;
        group.add(keeper);
      });

      // Case body — axis along Z (face to camera)
      const caseGeo = new THREE.CylinderGeometry(1.28, 1.28, 0.52, 64);
      caseGeo.rotateX(Math.PI / 2);
      const caseMesh = new THREE.Mesh(caseGeo, caseMat);
      group.add(caseMesh);

      // Bezel
      const bezel = new THREE.Mesh(new THREE.TorusGeometry(1.13, 0.17, 28, 84), bezelMat);
      bezel.position.z = 0.24;
      group.add(bezel);

      // Crystal
      const crystal = new THREE.Mesh(
        new THREE.SphereGeometry(1.02, 48, 24, 0, Math.PI * 2, 0, Math.PI / 2.6),
        new THREE.MeshPhysicalMaterial({ color: 0xffffff, metalness: 0, roughness: 0.02, transparent: true, opacity: 0.1, clearcoat: 1 })
      );
      crystal.rotation.x = Math.PI / 2;
      crystal.scale.set(1, 1, 0.32);
      crystal.position.z = 0.28;
      group.add(crystal);

      // Dial
      const dialMesh = new THREE.Mesh(new THREE.CircleGeometry(0.97, 56), dialMat);
      dialMesh.position.z = 0.265;
      group.add(dialMesh);

      // Hour markers — 12 applied batons
      const batonGeo = new THREE.BoxGeometry(0.055, 0.19, 0.02);
      const batonMat = new THREE.MeshStandardMaterial({ color: 0xd8c793, metalness: 1, roughness: 0.28 });
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        const baton = new THREE.Mesh(batonGeo, batonMat);
        baton.position.set(Math.sin(a) * 0.74, Math.cos(a) * 0.74, 0.285);
        baton.rotation.z = -a;
        group.add(baton);
      }

      // Hands — driven by the real clock
      const hourHand = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.46, 0.02), batonMat);
      hourHand.geometry.translate(0, 0.18, 0);
      hourHand.position.z = 0.3;
      group.add(hourHand);
      const minuteHand = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.72, 0.02), batonMat);
      minuteHand.geometry.translate(0, 0.29, 0);
      minuteHand.position.z = 0.305;
      group.add(minuteHand);
      const secondHand = new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.8, 0.012), new THREE.MeshBasicMaterial({ color: 0xe0654f }));
      secondHand.geometry.translate(0, 0.3, 0);
      secondHand.position.z = 0.31;
      group.add(secondHand);
      const pin = new THREE.Mesh(new THREE.CircleGeometry(0.055, 24), batonMat);
      pin.position.z = 0.315;
      group.add(pin);

      // Crown + two pushers
      const crownGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.18, 24);
      crownGeo.rotateZ(Math.PI / 2);
      const crown = new THREE.Mesh(crownGeo, caseMat);
      crown.position.set(1.36, 0, 0);
      group.add(crown);
      [0.42, -0.42].forEach((y) => {
        const pusherGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.14, 18);
        pusherGeo.rotateZ(Math.PI / 2);
        const pusher = new THREE.Mesh(pusherGeo, caseMat);
        pusher.position.set(1.32, y, 0);
        group.add(pusher);
      });

      group.scale.setScalar(0.92);

      return {
        camera,
        scene,
        tick: (t: number) => {
          const { px, py } = parallax.lerp();
          group.rotation.y = Math.sin(t * 0.45) * 0.38 + px * 0.55;
          group.rotation.x = Math.cos(t * 0.32) * 0.08 - py * 0.32;
          group.position.y = Math.sin(t * 0.9) * 0.07;

          // Real-time hands
          const now = new Date();
          const s = now.getSeconds() + now.getMilliseconds() / 1000;
          const m = now.getMinutes() + s / 60;
          const h = (now.getHours() % 12) + m / 60;
          secondHand.rotation.z = -(s / 60) * Math.PI * 2;
          minuteHand.rotation.z = -(m / 60) * Math.PI * 2;
          hourHand.rotation.z = -(h / 12) * Math.PI * 2;
        },
      };
    });

    return () => {
      parallax.dispose();
      materialsRef.current = null;
      cleanup();
    };
  }, []);

  // Live material updates without rebuilding the scene
  useEffect(() => {
    const mats = materialsRef.current;
    if (!mats) return;
    mats.caseMat.color.setHex(CASE_COLORS[caseFinish]);
    mats.bezelMat.color.setHex(CASE_COLORS[caseFinish]).multiplyScalar(0.88);
  }, [caseFinish]);
  useEffect(() => {
    const mats = materialsRef.current;
    if (!mats) return;
    mats.dialMat.color.setHex(DIAL_COLORS[dial].face);
    mats.dialMat.emissive.setHex(DIAL_COLORS[dial].emissive);
  }, [dial]);
  useEffect(() => {
    const mats = materialsRef.current;
    if (!mats) return;
    mats.strapMat.color.setHex(STRAP_COLORS[strap]);
  }, [strap]);

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />;
}
