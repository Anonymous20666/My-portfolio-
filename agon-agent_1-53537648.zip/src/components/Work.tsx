import { useEffect, useState } from 'react';
import { ArrowRight, ArrowUpRight, MapPin, Trophy, X } from 'lucide-react';
import { Modal } from './ui';
import { ProjectScene } from './scenes';
import { projects, type Project } from '../data';
import { pushToast, requestStart } from '../lib/hooks';

function WorkCard({ project, onOpen }: { project: Project; onOpen: (p: Project) => void }) {
  return (
    <button
      onClick={() => onOpen(project)}
      className="group relative overflow-hidden rounded-3xl border border-line bg-card text-left transition-all duration-500 hover:-translate-y-1.5 hover:border-line-2 focus-visible:-translate-y-1.5"
      aria-label={`Open case study: ${project.title}`}
    >
      {/* 3D stage */}
      <div className="relative h-56 overflow-hidden sm:h-60" style={{ background: `radial-gradient(130% 120% at 50% 0%, ${project.accent}14 0%, #0d0c15 60%)` }}>
        <ProjectScene
          variant={project.variant}
          accent={project.accent}
          className="absolute inset-0 h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.06]"
        />
        <span className="pointer-events-none absolute left-5 top-4 font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-mute">
          {project.index} / 06
        </span>
        {project.award && (
          <span className="absolute right-4 top-4 inline-flex items-center gap-1.5 rounded-full border border-gold/25 bg-gold/10 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-gold backdrop-blur-sm">
            <Trophy size={10} strokeWidth={2.2} /> {project.award.split('·')[0].trim()}
          </span>
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
      </div>

      {/* meta */}
      <div className="flex items-end justify-between gap-3 p-5">
        <div className="min-w-0">
          <h3 className="font-display text-lg font-semibold leading-tight tracking-tight text-ivory">{project.title}</h3>
          <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.14em] text-mute">
            {project.sector} · {project.year}
          </p>
        </div>
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-line-2 text-mute transition-all duration-300 group-hover:border-accent group-hover:bg-accent group-hover:text-white">
          <ArrowUpRight size={17} strokeWidth={2} />
        </span>
      </div>
    </button>
  );
}

function CaseStudyModal({ project, onClose }: { project: Project | null; onClose: () => void }) {
  return (
    <Modal open={!!project} onClose={onClose} maxWidth="max-w-3xl" label={project ? `Case study — ${project.title}` : 'Case study'}>
      {project && (
        <div className="overflow-y-auto slim-scroll">
          {/* banner with live scene */}
          <div className="relative h-40 shrink-0 overflow-hidden sm:h-48" style={{ background: `radial-gradient(120% 150% at 50% 0%, ${project.accent}1f 0%, #0c0b13 65%)` }}>
            <ProjectScene variant={project.variant} accent={project.accent} className="absolute inset-0 h-full w-full" />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-panel to-transparent" />
            <div className="absolute bottom-4 left-6 pr-16">
              <p className="font-display text-[9.5px] font-semibold uppercase tracking-[0.26em] text-accent-soft">Case study {project.index}</p>
              <h3 className="mt-1 font-display text-2xl font-semibold tracking-tight text-white sm:text-3xl">{project.title}</h3>
            </div>
          </div>

          <div className="px-6 pb-7 pt-5 sm:px-8">
            <p className="font-serif text-lg italic leading-snug text-ivory/90">“{project.tagline}”</p>

            {/* meta row */}
            <div className="mt-5 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-4">
              {[
                ['Sector', project.sector],
                ['Year', project.year],
                ['Location', project.location],
                ['Services', project.services.slice(0, 2).join(', ')],
              ].map(([k, v]) => (
                <div key={k} className="bg-panel-2 px-3 py-3">
                  <p className="text-[9px] font-semibold uppercase tracking-[0.18em] text-mute">{k}</p>
                  <p className="mt-1 text-[11.5px] font-medium leading-snug text-ivory">{v}</p>
                </div>
              ))}
            </div>

            {/* KPIs */}
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {project.kpis.map((kpi) => (
                <div key={kpi.label} className="rounded-2xl border border-line bg-white/[0.02] px-3 py-3.5">
                  <p className="font-display text-xl font-semibold tracking-tight text-accent-2 tabular-nums">{kpi.value}</p>
                  <p className="mt-1 text-[9.5px] font-medium uppercase leading-snug tracking-[0.09em] text-mute">{kpi.label}</p>
                </div>
              ))}
            </div>

            {/* narrative */}
            <div className="mt-6 grid gap-5 md:grid-cols-2">
              <div>
                <p className="font-display text-[10px] font-semibold uppercase tracking-[0.22em] text-mute">The challenge</p>
                <p className="mt-2 text-[13px] leading-relaxed text-ivory/85">{project.challenge}</p>
              </div>
              <div>
                <p className="font-display text-[10px] font-semibold uppercase tracking-[0.22em] text-accent-2">The Vivid3D answer</p>
                <p className="mt-2 text-[13px] leading-relaxed text-ivory/85">{project.solution}</p>
              </div>
            </div>

            {/* stack + award */}
            <div className="mt-6 flex flex-wrap items-center gap-2">
              {project.stack.map((tech) => (
                <span key={tech} className="rounded-lg border border-line bg-panel-2 px-2.5 py-1.5 font-mono text-[10.5px] text-accent-soft">{tech}</span>
              ))}
            </div>
            {project.award && (
              <p className="mt-5 flex items-center gap-2 text-[12px] font-medium text-gold">
                <Trophy size={14} strokeWidth={2} /> {project.award}
              </p>
            )}

            {/* CTAs */}
            <div className="mt-7 flex flex-wrap items-center gap-3 border-t border-line pt-6">
              <button
                className="btn btn-primary"
                onClick={() => {
                  onClose();
                  requestStart(`We're drawn to the ${project.title} case — we need a similar outcome. Here's our context:\n`);
                }}
              >
                Build something like this <ArrowRight size={15} strokeWidth={2.4} />
              </button>
              <button className="btn btn-ghost" onClick={onClose}>Back to all work <X size={14} /></button>
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
}

export default function Work() {
  const [active, setActive] = useState<Project | null>(null);

  useEffect(() => {
    document.body.style.overflow = active ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [active]);

  return (
    <section id="work" className="relative scroll-mt-20 border-b border-line">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-2xl">
            <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">Selected work · 2024 — 2026</p>
            <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl lg:text-6xl">
              Case studies,<br />
              <span className="font-serif italic font-normal text-gradient">alive in the browser.</span>
            </h2>
          </div>
          <button
            onClick={() => pushToast('Full credentials deck (PDF) requested — check your inbox within the hour.')}
            className="group inline-flex shrink-0 items-center gap-2 font-display text-[12px] font-semibold uppercase tracking-[0.18em] text-accent-soft transition-colors hover:text-white"
          >
            Request full deck
            <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <WorkCard key={project.id} project={project} onOpen={setActive} />
          ))}
        </div>

        <p className="mt-8 flex items-center justify-center gap-2 text-center text-[11px] text-mute">
          <MapPin size={12} /> Every canvas on this page is live WebGL — rendered on your device, right now.
        </p>
      </div>

      <CaseStudyModal project={active} onClose={() => setActive(null)} />
    </section>
  );
}
