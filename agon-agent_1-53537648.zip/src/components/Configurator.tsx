import { useMemo, useState } from 'react';
import { BadgeCheck, ChevronRight } from 'lucide-react';
import { WatchScene, type CaseFinish, type DialColor, type StrapColor } from './scenes';
import { requestStart, pushToast } from '../lib/hooks';

const CASES: { id: CaseFinish; label: string; delta: number; swatch: string; code: string }[] = [
  { id: 'steel', label: 'Oyster Steel', delta: 0, swatch: 'linear-gradient(135deg,#f2f3f7,#b9bbc6)', code: 'ST' },
  { id: 'black', label: 'Black DLC', delta: 240, swatch: 'linear-gradient(135deg,#3a3a44,#141419)', code: 'DK' },
  { id: 'rose', label: 'Rose Gold 5N', delta: 880, swatch: 'linear-gradient(135deg,#f2b79b,#c97a5b)', code: 'RG' },
];
const DIALS: { id: DialColor; label: string; delta: number; swatch: string; code: string }[] = [
  { id: 'midnight', label: 'Midnight Fumé', delta: 0, swatch: 'radial-gradient(circle at 35% 35%,#24335c,#0e1730)', code: 'MNT' },
  { id: 'ivory', label: 'Ivory Laquer', delta: 0, swatch: 'radial-gradient(circle at 35% 35%,#fdfbf2,#d9d4c3)', code: 'IVR' },
  { id: 'green', label: 'British Racing', delta: 150, swatch: 'radial-gradient(circle at 35% 35%,#175c40,#081f15)', code: 'BRG' },
  { id: 'slate', label: 'Slate Grained', delta: 0, swatch: 'radial-gradient(circle at 35% 35%,#3a3a46,#17171f)', code: 'SLT' },
  { id: 'champagne', label: 'Champagne Soleil', delta: 150, swatch: 'radial-gradient(circle at 35% 35%,#ecd494,#a8873f)', code: 'CHM' },
];
const STRAPS: { id: StrapColor; label: string; delta: number; swatch: string; code: string }[] = [
  { id: 'black', label: 'Nappa Black', delta: 0, swatch: 'linear-gradient(135deg,#2a2724,#0e0d0b)', code: 'BLK' },
  { id: 'tan', label: 'Cognac Calf', delta: 120, swatch: 'linear-gradient(135deg,#a8683a,#5e3a1e)', code: 'TAN' },
  { id: 'forest', label: 'Forest Suede', delta: 120, swatch: 'linear-gradient(135deg,#2c5240,#12241b)', code: 'FRS' },
];
const BASE_PRICE = 2400;

function formatEUR(n: number) {
  return n.toLocaleString('de-DE', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
}

function OptionRow<T extends string>({
  legend,
  options,
  value,
  onChange,
}: {
  legend: string;
  options: { id: T; label: string; delta: number; swatch: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <fieldset>
      <legend className="label">{legend}</legend>
      <div className="flex flex-wrap gap-2.5">
        {options.map((opt) => {
          const active = opt.id === value;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => onChange(opt.id)}
              aria-pressed={active}
              title={opt.label}
              className={`group flex items-center gap-2 rounded-2xl border py-1.5 pl-1.5 pr-3 transition-all duration-200 ${
                active ? 'border-accent bg-accent/12 shadow-[0_0_0_1px_var(--color-accent)]' : 'border-line bg-white/[0.02] hover:border-line-2'
              }`}
            >
              <span className="h-6 w-6 rounded-full border border-white/15 shadow-inner" style={{ background: opt.swatch }} />
              <span className="text-left">
                <span className={`block text-[11px] font-semibold leading-tight ${active ? 'text-white' : 'text-ivory/85'}`}>{opt.label}</span>
                <span className="block text-[9px] tabular-nums text-mute">{opt.delta === 0 ? 'Included' : `+${formatEUR(opt.delta)}`}</span>
              </span>
            </button>
          );
        })}
      </div>
    </fieldset>
  );
}

export default function Configurator() {
  const [caseFinish, setCaseFinish] = useState<CaseFinish>('steel');
  const [dial, setDial] = useState<DialColor>('midnight');
  const [strap, setStrap] = useState<StrapColor>('black');

  const price = useMemo(
    () => BASE_PRICE + CASES.find((c) => c.id === caseFinish)!.delta + DIALS.find((d) => d.id === dial)!.delta + STRAPS.find((s) => s.id === strap)!.delta,
    [caseFinish, dial, strap]
  );
  const reference = useMemo(
    () => `ORB1-${CASES.find((c) => c.id === caseFinish)!.code}-${DIALS.find((d) => d.id === dial)!.code}-${STRAPS.find((s) => s.id === strap)!.code}`,
    [caseFinish, dial, strap]
  );

  const reserve = () => {
    const summary = `Orbit One reservation — reference ${reference}. Case: ${CASES.find((c) => c.id === caseFinish)!.label}, dial: ${DIALS.find((d) => d.id === dial)!.label}, strap: ${STRAPS.find((s) => s.id === strap)!.label} · ${formatEUR(price)}.`;
    requestStart(summary + '\n');
    pushToast('Configuration pinned to your brief.');
  };

  return (
    <section id="capability" className="relative overflow-hidden border-b border-line">
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 h-[620px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/10 blur-[160px]" />
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:gap-14 lg:px-8 lg:py-24">
        {/* Left: pitch */}
        <div className="relative flex flex-col justify-center lg:col-span-4">
          <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">Not a mock — a live demo</p>
          <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl">
            Don’t take our<br />word for it.<br />
            <span className="font-serif italic font-normal text-gradient">Configure one.</span>
          </h2>
          <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-mute">
            This is the actual engine we shipped for Lumen Horology — physically-based metals, a living fumé dial and a
            movement that keeps real time. Your customers get this, tuned to your catalogue.
          </p>
          <ul className="mt-6 space-y-2.5 text-[12.5px] text-ivory/80">
            {['PBR metal & lacquer shaders, tuned in-house', 'Hands driven by the device clock — it actually works', 'AR “try it on your wrist” on supported phones'].map((item) => (
              <li key={item} className="flex items-start gap-2.5">
                <BadgeCheck size={15} className="mt-0.5 shrink-0 text-accent-2" strokeWidth={2} />
                {item}
              </li>
            ))}
          </ul>
          <p className="mt-7 text-[11px] uppercase tracking-[0.2em] text-mute">
            Built for <span className="text-gold">Lumen Horology</span> · CSS Design Awards — WOTD
          </p>
        </div>

        {/* Center: the watch */}
        <div className="relative flex items-center justify-center lg:col-span-4">
          <div className="relative h-[380px] w-full max-w-sm sm:h-[460px] lg:h-[540px]">
            <div aria-hidden="true" className="absolute inset-0 rounded-full bg-[radial-gradient(circle_at_50%_45%,rgba(124,108,255,0.16),transparent_62%)]" />
            <WatchScene caseFinish={caseFinish} dial={dial} strap={strap} className="absolute inset-0 h-full w-full" />
            <div className="pointer-events-none absolute bottom-1 left-1/2 -translate-x-1/2 rounded-full border border-line-2 bg-black/55 px-3 py-1.5 backdrop-blur-md">
              <span className="font-mono text-[9px] uppercase tracking-[0.22em] text-accent-soft">{reference}</span>
            </div>
          </div>
        </div>

        {/* Right: controls */}
        <div className="relative lg:col-span-4">
          <div className="card flex h-full flex-col gap-5 p-6 sm:p-7">
            <div className="flex items-baseline justify-between gap-3 border-b border-line pb-4">
              <div>
                <p className="font-display text-lg font-semibold tracking-tight text-ivory">Orbit One</p>
                <p className="text-[10px] uppercase tracking-[0.2em] text-mute">Lumen Horology · 41mm</p>
              </div>
              <div className="text-right">
                <p className="font-display text-2xl font-semibold tabular-nums text-ivory">{formatEUR(price)}</p>
                <p className="text-[9.5px] uppercase tracking-[0.16em] text-mute">incl. VAT · ships in 6 wks</p>
              </div>
            </div>

            <OptionRow legend="Case & bezel" options={CASES} value={caseFinish} onChange={setCaseFinish} />
            <OptionRow legend="Dial" options={DIALS} value={dial} onChange={setDial} />
            <OptionRow legend="Strap" options={STRAPS} value={strap} onChange={setStrap} />

            <button onClick={reserve} className="btn btn-primary mt-auto w-full justify-center">
              Reserve — €150 deposit <ChevronRight size={15} strokeWidth={2.4} />
            </button>
            <p className="text-center text-[10px] text-mute">Fully refundable for 14 days · Engraved case back included</p>
          </div>
        </div>
      </div>
    </section>
  );
}
