import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ArrowUpRight, Menu, X } from 'lucide-react';
import { requestStart } from '../lib/hooks';

const LINKS = [
  { label: 'Work', href: '#work', id: 'work' },
  { label: 'Capabilities', href: '#capabilities', id: 'capabilities' },
  { label: 'Process', href: '#process', id: 'process' },
  { label: 'Studio', href: '#studio', id: 'studio' },
];

function LogoMark({ className = 'h-9 w-9' }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="nav-lg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#a89bff" />
          <stop offset="0.5" stopColor="#7c6cff" />
          <stop offset="1" stopColor="#3fe0c5" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="15" fill="#0b0a12" />
      <path d="M32 9 L53 21.5 V42.5 L32 55 L11 42.5 V21.5 Z" fill="none" stroke="url(#nav-lg)" strokeWidth="3.4" strokeLinejoin="round" />
      <path d="M32 9 V32 M32 32 L53 21.5 M32 32 L11 21.5" fill="none" stroke="url(#nav-lg)" strokeWidth="3" strokeLinejoin="round" opacity="0.9" />
      <circle cx="32" cy="32" r="3.2" fill="#3fe0c5" />
    </svg>
  );
}

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState<string>('');
  const progressRef = useRef<HTMLDivElement>(null);

  // scroll state + progress bar (rAF-throttled, no re-render per frame)
  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const y = window.scrollY || 0;
        setScrolled(y > 28);
        const doc = document.documentElement;
        const max = Math.max(1, doc.scrollHeight - doc.clientHeight);
        if (progressRef.current) progressRef.current.style.transform = `scaleX(${y / max})`;
        ticking = false;
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // scroll-spy
  useEffect(() => {
    const sections = LINKS.map((l) => document.getElementById(l.id)).filter(Boolean) as HTMLElement[];
    if (!sections.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: '-38% 0px -55% 0px', threshold: 0 }
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  // lock body scroll when mobile menu open + esc to close
  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-[#0b0a12]/78 backdrop-blur-xl border-b border-line' : 'bg-transparent border-b border-transparent'
      }`}
    >
      {/* scroll progress */}
      <div className="absolute inset-x-0 bottom-0 h-[2px] overflow-hidden">
        <div ref={progressRef} className="h-full w-full origin-left bg-gradient-to-r from-accent via-accent-soft to-accent-2" style={{ transform: 'scaleX(0)' }} />
      </div>

      <nav className="mx-auto flex h-[68px] max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8" aria-label="Primary navigation">
        <a href="#top" className="flex shrink-0 items-center gap-2.5" aria-label="Vivid3D — home">
          <LogoMark className="h-9 w-9" />
          <span className="font-display text-[21px] font-semibold tracking-tight text-ivory">
            Vivid<span className="text-gradient">3D</span>
          </span>
        </a>

        <div className="hidden items-center gap-7 md:flex">
          {LINKS.map((link) => (
            <a
              key={link.id}
              href={link.href}
              aria-current={active === link.id ? 'true' : undefined}
              className={`group relative font-display text-[12px] font-medium uppercase tracking-[0.16em] transition-colors ${
                active === link.id ? 'text-white' : 'text-mute hover:text-ivory'
              }`}
            >
              {link.label}
              <span
                className={`absolute -bottom-[3px] left-0 h-[2px] bg-gradient-to-r from-accent to-accent-2 transition-all duration-300 ${
                  active === link.id ? 'w-full' : 'w-0 group-hover:w-full'
                }`}
              />
            </a>
          ))}
        </div>

        <div className="flex shrink-0 items-center gap-2 sm:gap-3">
          <span className="hidden items-center gap-2 rounded-full border border-line-2 px-3 py-1.5 text-[10.5px] font-medium text-mute lg:inline-flex">
            <span className="alive-dot" /> Booking Q1 2027
          </span>
          <button onClick={() => requestStart()} className="btn btn-primary !px-4 !py-2.5 !text-[12px]">
            <span className="hidden xs:inline">Start a project</span>
            <span className="xs:hidden">Start</span>
            <ArrowRight size={14} strokeWidth={2.4} />
          </button>
          <button
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-line-2 text-ivory md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.28, ease: [0.2, 0.8, 0.2, 1] }}
            className="absolute inset-x-0 top-[68px] z-40 border-b border-line-2 bg-[#0b0a12]/96 backdrop-blur-2xl md:hidden"
          >
            <div className="mx-auto max-w-7xl px-5 pb-7 pt-3">
              <div className="hairline-x mb-5" />
              <ul className="divide-y divide-line">
                {LINKS.map((link, i) => (
                  <li key={link.id}>
                    <a
                      href={link.href}
                      onClick={() => setOpen(false)}
                      className="group flex items-center justify-between py-4"
                    >
                      <span className="flex items-baseline gap-4">
                        <span className="font-serif text-sm italic text-accent-soft">0{i + 1}</span>
                        <span className="font-display text-2xl font-semibold tracking-tight text-ivory">{link.label}</span>
                      </span>
                      <ArrowUpRight size={20} className="text-mute transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent-2" />
                    </a>
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex items-center justify-between gap-3">
                <div className="text-[11px] leading-relaxed text-mute">
                  <p className="font-semibold text-ivory">hello@vivid3d.studio</p>
                  <p>Lobeckstr 30–35, 10969 Berlin</p>
                </div>
                <a href="mailto:hello@vivid3d.studio" className="btn btn-ghost !px-4 !py-2.5 text-[12px]">
                  Email us <ArrowRight size={13} />
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
