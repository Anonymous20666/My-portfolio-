import { useState } from 'react';
import { CheckCircle2, Send, Linkedin, Instagram, Dribbble, Github, MapPin } from 'lucide-react';
import { Modal } from './ui';
import { useBerlinTime, pushToast, requestStart } from '../lib/hooks';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const legalDocs: Record<'imprint' | 'privacy', { title: string; body: string[] }> = {
  imprint: {
    title: 'Imprint',
    body: [
      'Vivid3D Studio GmbH · Lobeckstr 30–35, 10969 Berlin, Germany',
      'Managing Directors: Elena Voss, Marcus Iyer · Handelsregister HRB 214 908 B (Charlottenburg) · USt-IdNr. DE 347 902 118',
      'hello@vivid3d.studio · +49 30 304 678 00',
      'Responsible for content under § 18 Abs. 2 MStV: Elena Voss.',
    ],
  },
  privacy: {
    title: 'Privacy',
    body: [
      'Data minimisation by default. This site sets no advertising cookies and runs no cross-site trackers. Anonymous, aggregate analytics only (Vercel Analytics, no personal profiles).',
      'When you send a brief, your details are stored solely to answer it — never sold, never enriched, deleted on request within 30 days.',
      'You have the right to access, rectify and erase your data at any time: privacy@vivid3d.studio.',
      'WebGL scenes render locally on your device; no scene content leaves your browser.',
    ],
  },
};

function Newsletter() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const [error, setError] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!EMAIL_RE.test(email.trim())) {
      setError('Enter a valid email.');
      return;
    }
    try {
      const prev = JSON.parse(localStorage.getItem('vivid3d.newsletter') ?? '[]') as unknown[];
      localStorage.setItem('vivid3d.newsletter', JSON.stringify([...prev.slice(-49), { email: email.trim(), at: new Date().toISOString() }]));
    } catch {
      /* best effort */
    }
    setDone(true);
    pushToast('Welcome to The Render — one email a month, zero fluff.');
  };

  if (done) {
    return (
      <p className="flex items-center gap-2 rounded-2xl border border-accent-2/25 bg-accent-2/8 px-4 py-3 text-[12.5px] text-accent-2">
        <CheckCircle2 size={16} /> You’re on the list. See you in the next render.
      </p>
    );
  }

  return (
    <form onSubmit={submit} className="w-full max-w-sm" noValidate>
      <label htmlFor="nl-email" className="label">The Render — our monthly letter</label>
      <div className="flex gap-2">
        <input
          id="nl-email"
          type="email"
          value={email}
          onChange={(e) => { setEmail(e.target.value); setError(''); }}
          placeholder="you@company.com"
          className={`input !rounded-xl ${error ? 'input-error' : ''}`}
          aria-label="Email for newsletter"
        />
        <button type="submit" aria-label="Subscribe" className="flex h-[46px] w-[46px] shrink-0 items-center justify-center rounded-xl bg-ivory text-ink transition-transform hover:scale-105">
          <Send size={16} strokeWidth={2.2} />
        </button>
      </div>
      {error && <p className="mt-1.5 text-[10.5px] text-[#f0857c]">{error}</p>}
    </form>
  );
}

const socialIcons = [
  { icon: Linkedin, label: 'LinkedIn', href: 'https://www.linkedin.com/company/vivid3d' },
  { icon: Dribbble, label: 'Dribbble', href: 'https://dribbble.com/vivid3d' },
  { icon: Instagram, label: 'Instagram', href: 'https://www.instagram.com/vivid3d.studio' },
  { icon: Github, label: 'GitHub', href: 'https://github.com/vivid3d' },
];

export default function Footer() {
  const berlinTime = useBerlinTime();
  const [doc, setDoc] = useState<'imprint' | 'privacy' | null>(null);

  return (
    <footer className="relative overflow-hidden bg-panel">
      <div aria-hidden="true" className="pointer-events-none absolute -left-40 top-0 h-96 w-96 rounded-full bg-accent/8 blur-[140px]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Top row */}
        <div className="flex flex-col gap-8 border-b border-line py-12 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-md">
            <a href="#top" className="font-display text-3xl font-semibold tracking-tight text-ivory">
              Vivid<span className="text-gradient">3D</span>
            </a>
            <p className="mt-3 text-[13px] leading-relaxed text-mute">
              Professional 3D experiences that feel alive — websites, configurators and brand worlds,
              fixed-bid from a Berlin studio since 2016.
            </p>
            <button onClick={() => requestStart()} className="btn btn-primary mt-5 !py-2.5 text-[12px]">Book a 30-min scoping call</button>
          </div>
          <Newsletter />
        </div>

        {/* Link columns */}
        <div className="grid grid-cols-2 gap-8 py-10 text-[13px] sm:grid-cols-4">
          <nav aria-label="Sitemap">
            <p className="label">Studio</p>
            <ul className="space-y-2.5">
              <li><a href="#work" className="text-mute transition-colors hover:text-ivory">Work</a></li>
              <li><a href="#capabilities" className="text-mute transition-colors hover:text-ivory">Capabilities</a></li>
              <li><a href="#process" className="text-mute transition-colors hover:text-ivory">Process</a></li>
              <li><a href="#studio" className="text-mute transition-colors hover:text-ivory">About</a></li>
              <li><a href="#contact" className="text-mute transition-colors hover:text-ivory">Contact</a></li>
            </ul>
          </nav>
          <nav aria-label="Craft">
            <p className="label">Craft</p>
            <ul className="space-y-2.5">
              <li><a href="#capability" className="text-mute transition-colors hover:text-ivory">Live configurator</a></li>
              <li><a href="#capabilities" className="text-mute transition-colors hover:text-ivory">Real-time 3D</a></li>
              <li><a href="#capabilities" className="text-mute transition-colors hover:text-ivory">Configurators & CPQ</a></li>
              <li><a href="#capabilities" className="text-mute transition-colors hover:text-ivory">WebGL performance</a></li>
            </ul>
          </nav>
          <div>
            <p className="label">Visit</p>
            <ul className="space-y-2.5 text-mute">
              <li className="flex items-start gap-1.5"><MapPin size={13} className="mt-0.5 shrink-0" />Lobeckstr 30–35<br />10969 Berlin, DE</li>
              <li><a href="mailto:hello@vivid3d.studio" className="transition-colors hover:text-ivory">hello@vivid3d.studio</a></li>
              <li><a href="tel:+493030467800" className="transition-colors hover:text-ivory">+49 30 304 678 00</a></li>
            </ul>
          </div>
          <div>
            <p className="label">Elsewhere</p>
            <div className="flex gap-2">
              {socialIcons.map(({ icon: Icon, label, href }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-line text-mute transition-all hover:-translate-y-0.5 hover:border-accent hover:text-white">
                  <Icon size={15} strokeWidth={1.7} />
                </a>
              ))}
            </div>
            <p className="mt-4 inline-flex items-center gap-2 rounded-full border border-accent-2/25 bg-accent-2/8 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-accent-2">
              <span className="alive-dot" /> 2 roles open — come build
            </p>
          </div>
        </div>

        {/* Legal bar */}
        <div className="flex flex-col gap-4 border-t border-line py-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-[11px] text-mute">© 2026 Vivid3D Studio GmbH. All rights and shaders reserved.</p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[11px] text-mute">
            <button onClick={() => setDoc('imprint')} className="transition-colors hover:text-ivory">Imprint</button>
            <button onClick={() => setDoc('privacy')} className="transition-colors hover:text-ivory">Privacy</button>
            <span className="flex items-center gap-2 tabular-nums text-ivory/70">
              <span className="h-1.5 w-1.5 rounded-full bg-accent-2" />
              Berlin — {berlinTime} CET
            </span>
          </div>
        </div>
      </div>

      {/* Legal modal */}
      <Modal open={doc !== null} onClose={() => setDoc(null)} maxWidth="max-w-md" label={doc ? legalDocs[doc].title : 'Legal'}>
        {doc && (
          <div className="overflow-y-auto slim-scroll px-6 pb-7 pt-6">
            <p className="font-display text-[10px] font-semibold uppercase tracking-[0.24em] text-accent-2">Legal</p>
            <h3 className="mt-2 font-display text-2xl font-semibold tracking-tight text-ivory">{legalDocs[doc].title}</h3>
            <div className="mt-4 space-y-3 text-[13px] leading-relaxed text-mute">
              {legalDocs[doc].body.map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
          </div>
        )}
      </Modal>
    </footer>
  );
}
