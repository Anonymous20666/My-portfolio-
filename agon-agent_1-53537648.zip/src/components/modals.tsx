import { Modal } from './ui';
import InquiryForm from './InquiryForm';
import { Clapperboard } from 'lucide-react';

export function ReelModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <Modal open={open} onClose={onClose} maxWidth="max-w-4xl" label="Vivid3D showreel">
      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto slim-scroll">
        <div className="flex items-center gap-3 border-b border-line px-6 py-4 pr-16">
          <Clapperboard size={16} className="text-accent-2" />
          <p className="font-display text-sm font-semibold tracking-wide text-ivory">VIVID3D — SHOWREEL 2026 <span className="text-mute">/ 0:16</span></p>
        </div>
        <div className="bg-black">
          {open && (
            <video
              key="reel"
              className="aspect-video w-full object-cover"
              src="/videos/reel.mp4"
              autoPlay
              loop
              controls
              playsInline
              preload="auto"
            />
          )}
        </div>
        <div className="flex flex-col gap-2 border-t border-line px-6 py-4 text-[11px] leading-relaxed text-mute sm:flex-row sm:items-center sm:justify-between">
          <span>Shot in-camera · no stock plates · scores by our in-house sound design</span>
          <span className="font-display uppercase tracking-[0.18em] text-[10px] text-accent-soft">Awwwards · FWA · CSSDA</span>
        </div>
      </div>
    </Modal>
  );
}

export function StartProjectModal({ open, onClose, prefill }: { open: boolean; onClose: () => void; prefill: string }) {
  return (
    <Modal open={open} onClose={onClose} maxWidth="max-w-lg" label="Start a project">
      <div className="overflow-y-auto slim-scroll px-6 pb-6 pt-6 sm:px-7">
        <p className="font-display text-[10px] font-semibold uppercase tracking-[0.22em] text-accent-2">Start a project</p>
        <h3 className="mt-2 font-display text-2xl font-semibold leading-tight tracking-tight text-ivory">
          Tell us where it <span className="font-serif italic font-normal text-gradient">hurts.</span>
        </h3>
        <p className="mt-2 text-[13px] leading-relaxed text-mute">
          Six lines is enough. We’ll bring a senior team, a fixed bid and the receipts — within one business day.
        </p>
        <div className="mt-5">
          <InquiryForm compact prefill={prefill} onDone={onClose} />
        </div>
      </div>
    </Modal>
  );
}
