import { useEffect, useState } from 'react';
import { CheckCircle2, Loader2, Send } from 'lucide-react';
import { pushToast } from '../lib/hooks';

const BUDGETS = ['€25k – €50k', '€50k – €100k', '€100k – €250k', '€250k+', 'Not sure yet'];

interface FormState {
  name: string;
  email: string;
  company: string;
  budget: string;
  message: string;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export default function InquiryForm({
  prefill = '',
  compact = false,
  onDone,
}: {
  prefill?: string;
  compact?: boolean;
  onDone?: () => void;
}) {
  const [form, setForm] = useState<FormState>({ name: '', email: '', company: '', budget: BUDGETS[1], message: prefill });
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [status, setStatus] = useState<'idle' | 'sending' | 'done'>('idle');
  const uid = compact ? 'mdl' : 'pg'; // unique field ids when both forms coexist

  useEffect(() => {
    if (prefill) setForm((f) => ({ ...f, message: prefill }));
  }, [prefill]);

  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [key]: e.target.value }));
    setErrors((err) => ({ ...err, [key]: undefined }));
  };

  const validate = () => {
    const next: typeof errors = {};
    if (form.name.trim().length < 2) next.name = 'Please tell us your name.';
    if (!EMAIL_RE.test(form.email.trim())) next.email = 'That email doesn’t look right.';
    if (form.message.trim().length < 20) next.message = 'A little more detail helps — at least 20 characters.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (status === 'sending' || !validate()) return;
    setStatus('sending');
    window.setTimeout(() => {
      try {
        const prev = JSON.parse(localStorage.getItem('vivid3d.inquiries') ?? '[]') as unknown[];
        localStorage.setItem(
          'vivid3d.inquiries',
          JSON.stringify([...prev.slice(-19), { ...form, at: new Date().toISOString() }])
        );
      } catch {
        /* storage is best-effort */
      }
      setStatus('done');
      pushToast('Inquiry received — we reply within one business day.');
    }, 1000);
  };

  if (status === 'done') {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-10 text-center">
        <div className="flex h-16 w-16 items-center justify-center rounded-full border border-accent-2/30 bg-accent-2/10">
          <CheckCircle2 size={30} className="text-accent-2" strokeWidth={1.8} />
        </div>
        <div>
          <p className="font-display text-xl font-semibold text-ivory">Brief received.</p>
          <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-mute">
            Thank you, {form.name.split(' ')[0] || 'friend'} — a senior producer will reach out within one business
            day to schedule a 30-minute walkthrough.
          </p>
        </div>
        <button
          className="btn btn-ghost text-xs"
          onClick={() => {
            setStatus('idle');
            setForm({ name: '', email: '', company: '', budget: BUDGETS[1], message: '' });
            onDone?.();
          }}
        >
          Send another brief
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="space-y-4">
      <div className={`grid gap-4 ${compact ? '' : 'sm:grid-cols-2'}`}>
        <div>
          <label className="label" htmlFor={`${uid}-name`}>Name</label>
          <input id={`${uid}-name`} className={`input ${errors.name ? 'input-error' : ''}`} placeholder="Ada Lovelace"
            value={form.name} onChange={set('name')} autoComplete="name" aria-invalid={!!errors.name} />
          {errors.name && <p className="mt-1.5 text-[11px] text-[#f0857c]">{errors.name}</p>}
        </div>
        <div>
          <label className="label" htmlFor={`${uid}-email`}>Work email</label>
          <input id={`${uid}-email`} type="email" className={`input ${errors.email ? 'input-error' : ''}`} placeholder="ada@company.com"
            value={form.email} onChange={set('email')} autoComplete="email" aria-invalid={!!errors.email} />
          {errors.email && <p className="mt-1.5 text-[11px] text-[#f0857c]">{errors.email}</p>}
        </div>
      </div>
      <div className={`grid gap-4 ${compact ? '' : 'sm:grid-cols-2'}`}>
        <div>
          <label className="label" htmlFor={`${uid}-company`}>Company <span className="normal-case text-[#6b6980]">(optional)</span></label>
          <input id={`${uid}-company`} className="input" placeholder="Analytical Engines Ltd"
            value={form.company} onChange={set('company')} autoComplete="organization" />
        </div>
        <div>
          <label className="label" htmlFor={`${uid}-budget`}>Budget range</label>
          <select id={`${uid}-budget`} className="input" value={form.budget} onChange={set('budget')}>
            {BUDGETS.map((b) => (
              <option key={b} value={b} className="bg-panel-2">{b}</option>
            ))}
          </select>
        </div>
      </div>
      <div>
        <label className="label" htmlFor={`${uid}-message`}>What are we building?</label>
        <textarea id={`${uid}-message`} rows={compact ? 3 : 4}
          className={`input resize-none ${errors.message ? 'input-error' : ''}`}
          placeholder="An immersive launch site for our GT — story, configurator, commerce. Target date: spring 2027…"
          value={form.message} onChange={set('message')} aria-invalid={!!errors.message} />
        <div className="mt-1.5 flex items-center justify-between gap-3">
          {errors.message
            ? <p className="text-[11px] text-[#f0857c]">{errors.message}</p>
            : <span />}
          <span className={`text-[10px] tabular-nums ${form.message.trim().length >= 20 ? 'text-accent-2' : 'text-[#6b6980]'}`}>
            {form.message.trim().length}/20+
          </span>
        </div>
      </div>
      <button type="submit" disabled={status === 'sending'} className="btn btn-primary w-full justify-center">
        {status === 'sending'
          ? <><Loader2 size={16} className="animate-spin" /> Sending brief…</>
          : <><Send size={15} strokeWidth={2.2} /> Send inquiry</>}
      </button>
      <p className="text-center text-[10.5px] leading-relaxed text-[#6b6980]">
        NDA-friendly · No deck required · You’ll hear from a human, never a sequence.
      </p>
    </form>
  );
}
