import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Mail, MapPin, Phone, Timer, Linkedin, Instagram, Dribbble, Github, ArrowUpRight } from 'lucide-react';
import InquiryForm from './InquiryForm';
import { faqs } from '../data';

function FaqAccordion() {
  const [open, setOpen] = useState(0);
  return (
    <div className="divide-y divide-line overflow-hidden rounded-3xl border border-line bg-card">
      {faqs.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={i}>
            <button
              onClick={() => setOpen(isOpen ? -1 : i)}
              aria-expanded={isOpen}
              className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition-colors hover:bg-white/[0.02] sm:px-6 sm:py-5"
            >
              <span className={`font-display text-[14px] font-semibold tracking-tight transition-colors sm:text-[15px] ${isOpen ? 'text-white' : 'text-ivory'}`}>
                {item.q}
              </span>
              <ChevronDown size={17} className={`shrink-0 text-mute transition-transform duration-300 ${isOpen ? 'rotate-180 text-accent-2' : ''}`} />
            </button>
            <AnimatePresence initial={false}>
              {isOpen && (
                <motion.div
                  key="a"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3, ease: [0.32, 0.72, 0.2, 1] }}
                  className="overflow-hidden"
                >
                  <p className="px-5 pb-5 text-[13px] leading-relaxed text-mute sm:px-6">{item.a}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
}

const socials = [
  { icon: Linkedin, label: 'Vivid3D on LinkedIn', href: 'https://www.linkedin.com/company/vivid3d' },
  { icon: Dribbble, label: 'Vivid3D on Dribbble', href: 'https://dribbble.com/vivid3d' },
  { icon: Instagram, label: 'Vivid3D on Instagram', href: 'https://www.instagram.com/vivid3d.studio' },
  { icon: Github, label: 'Vivid3D engineering on GitHub', href: 'https://github.com/vivid3d' },
];

export default function Contact() {
  return (
    <>
      {/* ---------------------------------------------------------- FAQ --- */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">
          <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">Before you ask</p>
          <h2 className="mt-3 max-w-2xl font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl">
            Fair <span className="font-serif italic font-normal text-gradient">questions.</span>
          </h2>
          <div className="mt-8 lg:max-w-4xl">
            <FaqAccordion />
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------- Contact --- */}
      <section id="contact" className="relative scroll-mt-20 overflow-hidden border-b border-line">
        <div aria-hidden="true" className="pointer-events-none absolute -right-32 bottom-[-180px] h-[480px] w-[560px] rounded-full bg-accent/12 blur-[150px]" />
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-5 lg:gap-14 lg:px-8 lg:py-24">
          <div className="flex flex-col lg:col-span-2">
            <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">Start a project</p>
            <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.0] tracking-[-0.03em] text-ivory sm:text-5xl xl:text-6xl">
              Have a brief?<br />
              <span className="font-serif italic font-normal text-gradient">Let’s build something alive.</span>
            </h2>
            <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-mute">
              Send the rough version — half a page and three bullet points is plenty. A senior producer, not a sequence,
              replies within one business day.
            </p>

            <ul className="mt-8 space-y-4 text-[13px]">
              <li>
                <a href="mailto:hello@vivid3d.studio" className="group flex items-center gap-3 text-ivory transition-colors hover:text-white">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-card text-accent-soft"><Mail size={17} strokeWidth={1.8} /></span>
                  <span><span className="block text-[9px] uppercase tracking-[0.2em] text-mute">Email</span>hello@vivid3d.studio</span>
                  <ArrowUpRight size={14} className="text-mute opacity-0 transition-opacity group-hover:opacity-100" />
                </a>
              </li>
              <li>
                <a href="tel:+493030467800" className="group flex items-center gap-3 text-ivory transition-colors hover:text-white">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-card text-accent-soft"><Phone size={17} strokeWidth={1.8} /></span>
                  <span><span className="block text-[9px] uppercase tracking-[0.2em] text-mute">Studio</span>+49 30 304 678 00</span>
                  <ArrowUpRight size={14} className="text-mute opacity-0 transition-opacity group-hover:opacity-100" />
                </a>
              </li>
              <li>
                <a href="https://www.google.com/maps/search/Lobeckstr+30-35+10969+Berlin" target="_blank" rel="noreferrer" className="group flex items-center gap-3 text-ivory transition-colors hover:text-white">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-card text-accent-soft"><MapPin size={17} strokeWidth={1.8} /></span>
                  <span><span className="block text-[9px] uppercase tracking-[0.2em] text-mute">Visit</span>Lobeckstr 30–35, 10969 Berlin</span>
                  <ArrowUpRight size={14} className="text-mute opacity-0 transition-opacity group-hover:opacity-100" />
                </a>
              </li>
              <li className="flex items-center gap-3 text-ivory">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-card text-accent-soft"><Timer size={17} strokeWidth={1.8} /></span>
                <span><span className="block text-[9px] uppercase tracking-[0.2em] text-mute">Response</span>Within one business day, guaranteed</span>
              </li>
            </ul>

            <div className="mt-8 flex items-center gap-2">
              {socials.map(({ icon: Icon, label, href }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-line text-mute transition-all hover:-translate-y-0.5 hover:border-accent hover:text-white">
                  <Icon size={17} strokeWidth={1.7} />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="card p-6 sm:p-8">
              <InquiryForm />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
