import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, Quote, Trophy } from 'lucide-react';
import { awardMarks, team, testimonials } from '../data';

function TestimonialCarousel() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    if (paused) return;
    const id = window.setInterval(() => {
      if (mounted.current) setIndex((i) => (i + 1) % testimonials.length);
    }, 5200);
    return () => {
      mounted.current = false;
      window.clearInterval(id);
    };
  }, [paused]);

  const current = testimonials[index];
  const go = (dir: 1 | -1) => setIndex((i) => (i + dir + testimonials.length) % testimonials.length);

  return (
    <div
      className="relative overflow-hidden rounded-3xl border border-line bg-card p-6 sm:p-10"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="Client testimonials"
    >
      <Quote size={44} strokeWidth={1.4} className="absolute right-6 top-6 text-line-2" />
      <AnimatePresence mode="wait">
        <motion.figure
          key={index}
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -14 }}
          transition={{ duration: 0.42, ease: [0.32, 0.72, 0.2, 1] }}
        >
          <blockquote className="max-w-3xl font-serif text-xl italic leading-snug text-ivory/95 sm:text-2xl">
            “{current.quote}”
          </blockquote>
          <figcaption className="mt-6 flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-full bg-accent/20 font-display text-sm font-semibold text-accent-soft">
              {current.name.split(' ').map((p) => p[0]).join('')}
            </span>
            <span>
              <span className="block font-display text-sm font-semibold text-ivory">{current.name}</span>
              <span className="block text-[11px] text-mute">{current.role} · {current.company}</span>
            </span>
          </figcaption>
        </motion.figure>
      </AnimatePresence>
      <div className="mt-7 flex items-center justify-between gap-4">
        <div className="flex gap-1.5" role="tablist" aria-label="Choose testimonial">
          {testimonials.map((t, i) => (
            <button
              key={i}
              role="tab"
              aria-selected={i === index}
              aria-label={`Testimonial ${i + 1} — ${t.company}`}
              onClick={() => setIndex(i)}
              className={`h-1.5 rounded-full transition-all duration-300 ${i === index ? 'w-8 bg-accent-2' : 'w-2.5 bg-line-2 hover:bg-mute'}`}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => go(-1)} aria-label="Previous testimonial" className="flex h-9 w-9 items-center justify-center rounded-full border border-line-2 text-mute transition-colors hover:border-accent hover:text-white">
            <ArrowLeft size={15} />
          </button>
          <button onClick={() => go(1)} aria-label="Next testimonial" className="flex h-9 w-9 items-center justify-center rounded-full border border-line-2 text-mute transition-colors hover:border-accent hover:text-white">
            <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Studio() {
  return (
    <section id="studio" className="scroll-mt-20 border-b border-line">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="grid items-center gap-10 lg:grid-cols-12 lg:gap-14">
          {/* Visual */}
          <figure className="group relative overflow-hidden rounded-3xl border border-line lg:col-span-6">
            <img
              src="/images/studio.jpg"
              alt="The Vivid3D studio in Berlin at dusk — designers reviewing a real-time 3D scene on an LED wall"
              className="h-[300px] w-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.04] sm:h-[420px] lg:h-[560px]"
            />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/10 to-transparent" />
            <figcaption className="absolute bottom-4 left-5 right-5 flex flex-wrap items-end justify-between gap-3">
              <span>
                <span className="font-display text-[10px] font-semibold uppercase tracking-[0.24em] text-accent-2">The studio</span>
                <span className="mt-1 block text-[12px] text-ivory/85">Lobeckstr 30–35, Kreuzberg — Berlin</span>
              </span>
              <span className="rounded-full border border-white/20 bg-black/45 px-3 py-1.5 font-mono text-[9px] uppercase tracking-[0.2em] text-ivory/90 backdrop-blur-sm">EST. 2016</span>
            </figcaption>
          </figure>

          {/* Copy + team */}
          <div className="lg:col-span-6">
            <p className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-accent-2">The studio</p>
            <h2 className="mt-3 font-display text-4xl font-semibold leading-[1.02] tracking-[-0.03em] text-ivory sm:text-5xl">
              Thirteen specialists.<br />
              <span className="font-serif italic font-normal text-gradient">Zero account managers.</span>
            </h2>
            <p className="mt-5 max-w-lg text-[14px] leading-relaxed text-mute">
              You work directly with the people who touch the pixels — a tight pod of directors, CGI artists and engine
              engineers. No layers, no hand-offs, no “let me circle back”. Founders stay on every account, for life.
            </p>

            <ul className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
              {team.map((member) => (
                <li key={member.name} className="group text-center sm:text-left">
                  <img
                    src={member.img}
                    alt={member.name}
                    loading="lazy"
                    width={96}
                    height={96}
                    className="h-20 w-20 rounded-2xl border border-line object-cover transition-all duration-300 group-hover:border-accent sm:h-24 sm:w-24"
                  />
                  <p className="mt-2.5 font-display text-[12px] font-semibold leading-tight text-ivory">{member.name}</p>
                  <p className="mt-0.5 text-[9.5px] uppercase leading-snug tracking-[0.1em] text-mute">{member.role}</p>
                </li>
              ))}
            </ul>

            <div className="mt-8 border-t border-line pt-6">
              <p className="flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-mute">
                <Trophy size={12} className="text-gold" /> Recognised by
              </p>
              <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2">
                {awardMarks.map((mark) => (
                  <span key={mark} className="font-display text-[12px] font-medium uppercase tracking-[0.14em] text-mute transition-colors hover:text-gold">{mark}</span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 lg:mt-16">
          <TestimonialCarousel />
        </div>
      </div>
    </section>
  );
}
