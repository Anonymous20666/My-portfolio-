import { useEffect, useState } from 'react';
import Nav from './components/Nav';
import Hero from './components/Hero';
import Work from './components/Work';
import Configurator from './components/Configurator';
import Capabilities from './components/Capabilities';
import Studio from './components/Studio';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { ReelModal, StartProjectModal } from './components/modals';
import { ToastHost } from './components/ui';

export default function App() {
  const [reelOpen, setReelOpen] = useState(false);
  const [startOpen, setStartOpen] = useState(false);
  const [prefill, setPrefill] = useState('');

  // Global "open the project modal" signal (fired by nav CTA, configurator, case studies…)
  useEffect(() => {
    const handler = (e: Event) => {
      setPrefill((e as CustomEvent<string>).detail ?? '');
      setStartOpen(true);
    };
    window.addEventListener('vivid:start', handler);
    return () => window.removeEventListener('vivid:start', handler);
  }, []);

  return (
    <div className="relative min-h-screen bg-ink font-sans text-ivory">
      {/* ambient page glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(90%_60%_at_50%_-10%,rgba(124,108,255,0.12),transparent_60%)]"
      />
      <Nav />
      <main className="relative z-10">
        <Hero onWatchReel={() => setReelOpen(true)} />
        <Work />
        <Configurator />
        <Capabilities />
        <Studio />
        <Contact />
      </main>
      <Footer />
      <ReelModal open={reelOpen} onClose={() => setReelOpen(false)} />
      <StartProjectModal open={startOpen} onClose={() => setStartOpen(false)} prefill={prefill} />
      <ToastHost />
    </div>
  );
}
