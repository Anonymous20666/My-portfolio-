export type ProjectVariant = 'knot' | 'orbit' | 'grid' | 'gem' | 'torus' | 'wave';

export interface Project {
  id: string;
  index: string;
  title: string;
  sector: string;
  year: string;
  location: string;
  award?: string;
  tagline: string;
  challenge: string;
  solution: string;
  kpis: { value: string; label: string }[];
  stack: string[];
  services: string[];
  variant: ProjectVariant;
  accent: string;
}

export const projects: Project[] = [
  {
    id: 'aether',
    index: '01',
    title: 'Aether Atelier',
    sector: 'Haute Fashion',
    year: '2025',
    location: 'Paris, FR',
    award: 'Awwwards · Site of the Day',
    tagline: 'A couture house reimagined as a living, draped digital atelier.',
    challenge:
      'Aether Atelier needed to translate the movement of silk and the quiet theatre of a runway show into the browser — without sacrificing the 90+ Lighthouse scores their e-commerce P&L depends on.',
    solution:
      'We built a real-time garment viewer on WebGL with cloth-simulated morph targets, KTX2-compressed fabric shaders and a headless Shopify backbone. The runway season launch streamed at 60fps on a mid-range phone.',
    kpis: [
      { value: '+38%', label: 'Add-to-cart rate' },
      { value: '1.9s', label: 'Largest Contentful Paint' },
      { value: '2.1M', label: 'Virtual showroom visits' },
      { value: '96', label: 'Mobile Lighthouse' },
    ],
    stack: ['Three.js', 'GLSL', 'GSAP', 'Shopify', 'Sanity', 'KTX2'],
    services: ['Creative direction', 'Real-time 3D', 'E-commerce', 'Motion'],
    variant: 'knot',
    accent: '#a89bff',
  },
  {
    id: 'nexus',
    index: '02',
    title: 'Nexus Labs',
    sector: 'Infrastructure AI',
    year: '2025',
    location: 'Berlin, DE',
    award: 'FWA · of the Day',
    tagline: 'An interactive flight through 2,300 live infrastructure nodes.',
    challenge:
      'Nexus operates a distributed inference mesh. Their old marketing site described it with static diagrams nobody believed. Enterprise buyers needed to feel the scale before a single sales call.',
    solution:
      'A WebGL “data galaxy” rendered the live topology — real node health, latency and packet flow — inside an art-directed brand world. The demo-request rate became the board’s favourite metric.',
    kpis: [
      { value: '+52%', label: 'Demo requests' },
      { value: '97', label: 'Lighthouse performance' },
      { value: '3.4×', label: 'Avg. session duration' },
      { value: '0.8s', label: 'Time to interactive' },
    ],
    stack: ['Three.js', 'React 19', 'WebSockets', 'MDX', 'Vercel'],
    services: ['Real-time 3D', 'Data visualisation', 'Brand world', 'Engineering'],
    variant: 'orbit',
    accent: '#3fe0c5',
  },
  {
    id: 'horizon',
    index: '03',
    title: 'Horizon Pavilion',
    sector: 'Architecture',
    year: '2024',
    location: 'Copenhagen, DK',
    award: 'RIBA · Digital Award shortlist',
    tagline: 'An interactive digital twin of a harbourside landmark.',
    challenge:
      'The pavilion exists as a building — Vivid3D was asked to make it exist as an argument: light, massing and public flow, explorable by journalists, juries and the curious before a single foot crossed the site.',
    solution:
      'We instanced the full massing model into an interactive twin with season-aware sun studies, a guided “architect’s tour” mode and WebGPU-ready instancing that holds 60fps on integrated graphics.',
    kpis: [
      { value: '+64%', label: 'Press coverage vs. plan' },
      { value: '11:40', label: 'Avg. time in twin (min)' },
      { value: '1.2M', label: 'Immersive sessions, launch month' },
      { value: '91', label: 'Lighthouse accessibility' },
    ],
    stack: ['Three.js', 'WebGPU', 'glTF', 'Theatre.js', 'Next.js'],
    services: ['Digital twin', 'Real-time 3D', 'Interaction design', 'Accessibility'],
    variant: 'grid',
    accent: '#8fd0ff',
  },
  {
    id: 'meridia',
    index: '04',
    title: 'Meridia EV',
    sector: 'Electric Mobility',
    year: '2026',
    location: 'Munich, DE',
    award: 'Awwwards · Honorable Mention',
    tagline: 'The GT launch that configured itself — 240,000 times.',
    challenge:
      'Meridia’s flagship GT was six weeks from launch with no press-drive cars available. The entire campaign had to live in the browser: explode, configure, price, reserve — photoreal, on any device.',
    solution:
      'A full CPQ-class configurator: physically-based paint shaders with flake, dynamic studio lighting, AR “park your GT” mode and instant trade-in pricing wired to the dealer DMS.',
    kpis: [
      { value: '240k', label: 'Configurations in 8 weeks' },
      { value: '+41%', label: 'Qualified leads' },
      { value: '1.4M', label: 'Configurator sessions' },
      { value: '18%', label: 'Reserve-now conversion' },
    ],
    stack: ['Three.js', 'PBR', 'WebXR', 'Salesforce CPQ', 'Vercel Edge'],
    services: ['Product configurator', 'CGI', 'AR', 'Commerce'],
    variant: 'gem',
    accent: '#7cf0d4',
  },
  {
    id: 'lumen',
    index: '05',
    title: 'Lumen Horology',
    sector: 'Luxury Watches',
    year: '2026',
    location: 'Geneva, CH',
    award: 'CSS Design Awards · WOTD',
    tagline: 'A maison configurator worthy of the watch on your wrist.',
    challenge:
      'Lumen sells €18k timepieces to people who inspect gasket alignment. A flat gallery page was never going to earn the reservation — the wrist, the dial and the light had to be felt.',
    solution:
      'The Orbit One configurator — the same watch you can try live below — with real-time hand sweep, fumé dial shaders, engraved case backs and a concierge handoff to boutiques in 14 cities.',
    kpis: [
      { value: '+57%', label: 'Reservation rate' },
      { value: '9,200', label: 'Waitlist joins at launch' },
      { value: '14', label: 'Boutiques linked live' },
      { value: '38%', label: 'Sessions ending in configurator share' },
    ],
    stack: ['Three.js', 'GLSL', 'Spline', 'Shopify Plus', 'Algolia'],
    services: ['Product configurator', 'Real-time 3D', 'Commerce', 'Brand world'],
    variant: 'torus',
    accent: '#e7c268',
  },
  {
    id: 'orbital',
    index: '06',
    title: 'Orbital',
    sector: 'B2B SaaS · AI Ops',
    year: '2026',
    location: 'Remote · HQ Amsterdam',
    tagline: 'Turning an ops platform into an orbit you want to join.',
    challenge:
      'Orbital had a powerful AI ops engine wrapped in a brochure site. Activation stalled at signup — users couldn’t picture the first hour with the product, so they never took it.',
    solution:
      'We designed “The Orbit” — an interactive narrative flight from signal to resolution, wired straight into a sandbox tenant. Signed-up users rehearse the product before login; activation followed.',
    kpis: [
      { value: '+33%', label: 'Signup → activation' },
      { value: '97', label: 'Lighthouse performance' },
      { value: '4.6×', label: 'Pipeline from organic' },
      { value: '60fps', label: 'On 2019 Android hardware' },
    ],
    stack: ['React 19', 'Three.js', 'MDX', 'Vercel', 'PostHog'],
    services: ['Interaction design', 'Real-time 3D', 'Design system', 'Engineering'],
    variant: 'wave',
    accent: '#a89bff',
  },
];

export interface Capability {
  index: string;
  title: string;
  blurb: string;
  detail: string[];
  timeline: string;
  from: string;
}

export const capabilities: Capability[] = [
  {
    index: '01',
    title: 'Real-time 3D websites',
    blurb: 'Cinematic WebGL experiences that load fast and rank.',
    detail: ['Three.js / React Three Fiber builds', 'Custom GLSL shaders & post-processing', 'glTF pipelines, KTX2 & Draco compression', '90+ Lighthouse contractual budget'],
    timeline: '8–14 weeks',
    from: '€48k',
  },
  {
    index: '02',
    title: 'Product configurators & CPQ',
    blurb: 'From swatch to signed quote, inside the browser.',
    detail: ['PBR material systems & studio lighting', 'AR “place it” via WebXR on mobile', 'CPQ / DMS / Shopify wiring', 'Reference-code & reservation flows'],
    timeline: '10–16 weeks',
    from: '€85k',
  },
  {
    index: '03',
    title: 'Interactive brand worlds',
    blurb: 'Campaigns and micro-sites people remember on Tuesday.',
    detail: ['Launch sites, showrooms & lookbooks', 'Scroll-driven narrative & Theatre.js', 'Sound-adaptive motion systems', 'Global CDN edge delivery'],
    timeline: '6–12 weeks',
    from: '€42k',
  },
  {
    index: '04',
    title: '3D product visualization',
    blurb: 'Photoreal CGI that replaces the product shoot.',
    detail: ['Exploded views & technical packshots', 'Lifestyle renders & turntable loops', 'Asset libraries for your whole range', 'Print-ready & web-ready outputs'],
    timeline: '3–6 weeks',
    from: '€18k',
  },
  {
    index: '05',
    title: 'WebGL performance engineering',
    blurb: '“It runs beautifully” — with the receipts.',
    detail: ['Frame-budget audits & draw-call diets', 'WASM hot paths, instancing, LODs', 'Accessibility-first fallbacks', 'Core Web Vitals rescue programmes'],
    timeline: '2–5 weeks',
    from: '€14k',
  },
];

export const processSteps = [
  {
    step: '01',
    title: 'Discover & define',
    weeks: 'Weeks 1–2',
    points: ['Stakeholder & audience workshops', 'Tech and asset audit', 'Motion & spatial art direction', 'Fixed scope, fixed bid, fixed date'],
  },
  {
    step: '02',
    title: 'Design & prototype',
    weeks: 'Weeks 2–4',
    points: ['Interactive WebGL prototypes, not slides', 'Real assets on real devices', 'Type, light and sound language', 'Sign-off gate before build'],
  },
  {
    step: '03',
    title: 'Build & tune',
    weeks: 'Weeks 4–12',
    points: ['Shader-level craft, asset pipelines', 'Weekly playable builds', 'Perf budget enforced in CI', 'You own the repo from day one'],
  },
  {
    step: '04',
    title: 'Launch & learn',
    weeks: 'Ongoing',
    points: ['Phased rollout & monitoring', 'Analytics-to-iteration loop', '30-day hypercare included', 'Retainer for continuous motion'],
  },
];

export const testimonials = [
  {
    quote: 'Vivid3D didn’t build us a website — they built a destination. Conversion doubled in six weeks and the board now opens every review with the showroom numbers.',
    name: 'Claire Beaumont',
    role: 'Chief Marketing Officer',
    company: 'Aether Atelier',
  },
  {
    quote: 'The only studio I’ve met that says “shader compile time” and “CAC payback” in the same sentence — and is right about both.',
    name: 'Jonas Rein',
    role: 'VP of Growth',
    company: 'Nexus Labs',
  },
  {
    quote: 'Twelve weeks, fixed bid, zero surprises. The pavilion’s digital twin outlasted the physical exhibition by a year — and out-shipped it to 40 countries.',
    name: 'Mette Dahl',
    role: 'Founding Partner',
    company: 'Horizon Pavilion',
  },
];

export const faqs = [
  {
    q: 'How long does a typical project take?',
    a: 'Websites and brand worlds run 8–14 weeks from signed brief to launch. Configurators run 10–16 weeks. Every engagement is fixed-scope and fixed-date — the timeline is in the contract, not in a slide.',
  },
  {
    q: 'What does a project cost?',
    a: 'Brand worlds from €42k, websites from €48k, configurators from €85k, CGI from €18k. We publish anchors because discovery should not be an ambush. A detailed estimate lands within three business days of a brief.',
  },
  {
    q: 'Who owns the code and the assets?',
    a: 'You do — fully, from day one. Repository, design files, 3D source assets and accounts are transferred at handover, and you never need our permission to ship it.',
  },
  {
    q: 'Can you work with our in-house team?',
    a: 'Yes — about 40% of our projects are embedded with in-house design or engineering teams. We slot into your rituals, your repo conventions and your review cycle.',
  },
  {
    q: 'What about performance and accessibility?',
    a: 'Performance budgets are written into the contract: ≥90 mobile Lighthouse and ≤1.5s LCP at p75. Every build ships keyboard-navigable, reduced-motion aware and screen-reader labelled.',
  },
  {
    q: 'Do you sign NDAs?',
    a: 'Of course — mutual or yours, before any brief leaves your inbox. Most conversations start under your paper; some start with a coffee in Berlin.',
  },
];

export const team = [
  { name: 'Elena Voss', role: 'Creative Director & Founder', img: 'https://randomuser.me/api/portraits/women/65.jpg' },
  { name: 'Marcus Iyer', role: 'WebGL Engineering Lead', img: 'https://randomuser.me/api/portraits/men/32.jpg' },
  { name: 'Sofia Lindqvist', role: 'Design Director', img: 'https://randomuser.me/api/portraits/women/44.jpg' },
  { name: 'Dana Kovac', role: 'CGI & Motion Artist', img: 'https://randomuser.me/api/portraits/men/75.jpg' },
];

export const clients = [
  'Aether Atelier',
  'Nexus Labs',
  'Horizon Pavilion',
  'Meridia',
  'Lumen Horology',
  'Orbital',
  'Karnak Group',
  'Vaya Airlines',
  'Ostro Bank',
  'Fieldnotes',
];

export const stats = [
  { value: 96, suffix: '', label: 'Projects shipped since 2016' },
  { value: 9, suffix: '', label: 'Awwwards & FWA recognitions' },
  { value: 97, suffix: '', label: 'Average Lighthouse score' },
  { value: 24, suffix: '', label: 'Countries with launched work' },
];

export const awardMarks = ['Awwwards', 'FWA', 'CSS Design Awards', 'The Webby Awards', 'Communication Arts'];
