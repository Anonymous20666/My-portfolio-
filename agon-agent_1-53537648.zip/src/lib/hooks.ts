import { useEffect, useRef, useState } from 'react';

/** Observe when an element enters the viewport (once). */
export function useInView<T extends HTMLElement>(threshold = 0.18, rootMargin = '0px 0px -8% 0px') {
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold, rootMargin }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold, rootMargin]);
  return { ref, inView };
}

/** Eased count-up when `active` flips true. */
export function useCountUp(target: number, active: boolean, duration = 1700, decimals = 0) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!active) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
      setValue(Number((target * eased).toFixed(decimals)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, target, duration, decimals]);
  return value;
}

/** Live Europe/Berlin clock string, ticking every second. */
export function useBerlinTime() {
  const [now, setNow] = useState(() =>
    new Date().toLocaleTimeString('en-GB', { timeZone: 'Europe/Berlin', hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );
  useEffect(() => {
    const id = setInterval(
      () =>
        setNow(
          new Date().toLocaleTimeString('en-GB', { timeZone: 'Europe/Berlin', hour: '2-digit', minute: '2-digit', second: '2-digit' })
        ),
      1000
    );
    return () => clearInterval(id);
  }, []);
  return now;
}

/** Fire a global toast (rendered by <ToastHost/>). */
export function pushToast(message: string) {
  window.dispatchEvent(new CustomEvent<string>('vivid:toast', { detail: message }));
}

/** Ask the app shell to open the project-inquiry modal, optionally prefilled. */
export function requestStart(prefill = '') {
  window.dispatchEvent(new CustomEvent<string>('vivid:start', { detail: prefill }));
}
